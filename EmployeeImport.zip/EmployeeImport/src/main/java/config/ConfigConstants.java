package config;

public interface ConfigConstants {
	String MESSAGE="メッセージ";
	String CONFIRM_EXECUTE="実行を確認してください";
	String VALIDATE_PATH_EMPTY="取込ファイルが存在しません。";
	String VALIDATE_NO_OVER="社員番号の桁数オーバー";
	String VALIDATE_NOT_NUMBER="社員番号が数字でない";
	String VALIDATE_FURIGANA_EMPTY="氏名（フリガナ）未入力";
	String VALIDATE_FURIGANA_OVER="氏名（フリガナ）桁数オーバー";
	String VALIDATE_NAME_EMPTY="氏名未入力";
	String VALIDATE_NAME_OVER="氏名桁数オーバー";
	String VALIDATE_EIJI_EMPTY="氏名（英字）未入力";
	String VALIDATE_EIJI_OVER="氏名（英字）桁数オーバー";
	String VALIDATE_ZAISEKIKKUBUN_NOT_EXIST="在籍区分未登録";
	String VALIDATE_BUMON_CODE_NOT_EXIST="部門コード未登録";
	String VALIDATE_GENDER_NOT_EXIST="性別未登録";
	String VALIDATE_BLOOD_TYPE_NOT_EXIST="血液型未登録";
	String VALIDATE_BIRTHDATE="生年月日が日付でない";
	String VALIDATE_NOT_EXIST_FILE="ファイルが存在しないか、無効です！";
	
}
