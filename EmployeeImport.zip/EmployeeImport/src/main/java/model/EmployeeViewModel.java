package model;

import repository.*;

import java.time.LocalDate;
import java.util.List;

import controller.ImportController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class EmployeeViewModel {
	private final EmployeeRepository employeeRepository;
	private final ObservableList<EmployeeDAO> employeeList = FXCollections.observableArrayList();
	private final EmployeeDAO employeeDAO = new EmployeeDAO();

	/**
	 * EmployeeViewModelのコンストラクタ。 EmployeeRepositoryを初期化し、従業員のリストを読み込む。
	 */
	public EmployeeViewModel() {
		this.employeeRepository = new EmployeeRepository();
		loadEmployees();
	}

	/**
	 * 従業員リストをEmployeeRepositoryから取得し、employeeListに設定する。
	 */
	public void loadEmployees() {
		employeeList.setAll(employeeRepository.getAllEmployees());
	}

	/**
	 * 従業員リストを返す。
	 * 
	 * @return 従業員リスト
	 */
	public ObservableList<EmployeeDAO> getEmployeeList() {
		return employeeList;
	}

	/**
	 * 現在選択されているEmployeeDAOを返す。
	 * 
	 * @return 現在のEmployeeDAO
	 */
	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	/**
	 * 新しい従業員を追加し、リストを更新する。
	 */
	public void addEmployee() {
		employeeRepository.insertEmployee(employeeDAO);
		loadEmployees(); 
	}

	/**
	 * すべての従業員を削除し、リストを更新する。
	 */
	public void deleteAllEmployee() {
		employeeRepository.deleteAllEmployees();
		loadEmployees(); 
	}

	/**
	 * 現在選択されている従業員を削除し、リストを更新する。
	 */
	public void deleteEmployee() {
		employeeRepository.deleteEmployee(employeeDAO.shainNoProperty().get());
		loadEmployees(); 
	}

	/**
	 * EmployeeDAOを更新するためのメソッド。
	 * 
	 * @param shainNo 従業員番号
	 * @param shimeiKana フリガナ
	 * @param shimei 名前
	 * @param shimeiEiji 英字名
	 * @param zaisekiKb 在籍区分
	 * @param bumonCd 部門コード
	 * @param seibetsu 性別
	 * @param ketsuekiGata 血液型
	 * @param birthDate 生年月日
	 * @param createDate 作成日
	 * @param updateDate 更新日
	 */
	public void updateEmployeeDAO(int shainNo, String shimeiKana, String shimei, String shimeiEiji, String zaisekiKb,
			String bumonCd, String seibetsu, String ketsuekiGata, LocalDate birthDate, LocalDate createDate,
			LocalDate updateDate) {
		employeeDAO.shainNoProperty().set(shainNo);
		employeeDAO.shimeiKanaProperty().set(shimeiKana);
		employeeDAO.shimeiProperty().set(shimei);
		employeeDAO.shimeiEijiProperty().set(shimeiEiji);
		employeeDAO.zaisekiKbProperty().set(zaisekiKb);
		employeeDAO.bumonCdProperty().set(bumonCd);
		employeeDAO.seibetsuProperty().set(seibetsu);
		employeeDAO.ketsuekiGataProperty().set(ketsuekiGata);
		employeeDAO.birthDateProperty().set(birthDate);
		employeeDAO.createDateProperty().set(createDate);
		employeeDAO.updateDateProperty().set(updateDate);
	}

	/**
	 * Excelリストとデータベースリストを比較し、新規データのみをデータベースに追加します。
	 * 
	 * @param excelList Excelから読み込んだ従業員リスト
	 */
	public void compareAndAddEmployees(List<EmployeeDAO> excelList) {
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();

		for (EmployeeDAO excelEmployee : excelList) {
			boolean found = false;

			for (EmployeeDAO dbEmployee : dbList) {
				if (dbEmployee.shainNoProperty().get() == excelEmployee.shainNoProperty().get()) {
					found = true;
					break;
				}

			}

			// 新規データのみ追加取込を行う
			if (!found) {
				employeeRepository.insertEmployee(excelEmployee);
				ImportController.addCount++;
			}
		}
		loadEmployees();
	}

	/**
	 * 現在選択されている従業員情報をデータベースに更新し、リストを更新します。
	 */
	public void updateEmployee() {
		employeeRepository.updateEmployee(employeeDAO);
		loadEmployees();
	}

	/**
	 * Excelリストとデータベースリストを比較し、既存データを更新し、新規データを追加します。
	 * 
	 * @param excelList Excelから読み込んだ従業員リスト
	 */
	public void addAndUpdateEmployees(List<EmployeeDAO> excelList) {
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();

		for (EmployeeDAO excelEmployee : excelList) {
			boolean found = false;

			for (EmployeeDAO dbEmployee : dbList) {
				if (dbEmployee.shainNoProperty().get() == excelEmployee.shainNoProperty().get()) {
					found = true;
					employeeRepository.updateEmployee(excelEmployee);
					ImportController.updateCount++;
					break;
				}
			}

			if (!found) {
				employeeRepository.insertEmployee(excelEmployee);
				ImportController.addCount++;
			}
		}
		loadEmployees();
	}

	/**
	 * Excelリストの従業員情報を使用して、データベースの従業員情報を消除し、置き換えます。
	 * 
	 * @param excelList Excelから読み込んだ従業員リスト
	 */
	public void replaceEmployees(List<EmployeeDAO> excelList) {
		for (EmployeeDAO emp : excelList) {
			updateEmployeeDAO(emp.shainNoProperty().get(), emp.shimeiKanaProperty().get(), emp.shimeiProperty().get(),
					emp.shimeiEijiProperty().get(), emp.zaisekiKbProperty().get(), emp.bumonCdProperty().get(),
					emp.seibetsuProperty().get(), emp.ketsuekiGataProperty().get(), emp.birthDateProperty().get(),
					emp.createDateProperty().get(), emp.updateDateProperty().get());
			employeeRepository.insertEmployee(employeeDAO);
			ImportController.addCount++;
		}
		loadEmployees();
	}

}
