package repository;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import util.DatabaseConnection;

public class EmployeeRepository {
	private static final Logger logger = LogManager.getLogger(EmployeeRepository.class);

	/**
	 * すべての従業員情報をデータベースから取得します。
	 * 
	 * @return 従業員情報のリスト
	 */
	public List<EmployeeDAO> getAllEmployees() {
		List<EmployeeDAO> employees = new ArrayList<>();
		String query = "SELECT * FROM employees";

		try (Connection conn = DatabaseConnection.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {

			while (rs.next()) {
				EmployeeDAO e = new EmployeeDAO();
				e.shainNoProperty().set(rs.getInt("shain_no"));
				e.shimeiKanaProperty().set(rs.getString("shimei_kana"));
				e.shimeiProperty().set(rs.getString("shimei"));
				e.shimeiEijiProperty().set(rs.getString("shimei_eiji"));
				e.zaisekiKbProperty().set(rs.getString("zaiseki_kb"));
				e.bumonCdProperty().set(rs.getString("bumon_cd"));
				e.seibetsuProperty().set(rs.getString("seibetsu"));
				e.ketsuekiGataProperty().set(rs.getString("ketsueki_gata"));
				e.birthDateProperty()
						.set(rs.getDate("birth_date") != null ? rs.getDate("birth_date").toLocalDate() : null);
				e.createDateProperty().set(rs.getDate("create") != null ? rs.getDate("create").toLocalDate() : null);
				e.updateDateProperty().set(rs.getDate("update") != null ? rs.getDate("update").toLocalDate() : null);

				employees.add(e);
			}
		} catch (SQLException ex) {
			logger.error("getAllEmployees() SQLException: " + ex);
			ex.printStackTrace();
		}
		return employees;
	}

	/**
	 * 新しい従業員情報をデータベースに挿入します。
	 * 
	 * @param e 従業員情報
	 */
	public void insertEmployee(EmployeeDAO e) {
		String query = "INSERT INTO employees (shain_no, shimei_kana, shimei, shimei_eiji, zaiseki_kb, bumon_cd, seibetsu, ketsueki_gata, birth_date, \"create\", \"update\") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setInt(1, e.shainNoProperty().get());
			pstmt.setString(2, e.shimeiKanaProperty().get());
			pstmt.setString(3, e.shimeiProperty().get());
			pstmt.setString(4, e.shimeiEijiProperty().get());
			pstmt.setString(5, e.zaisekiKbProperty().get());
			pstmt.setString(6, e.bumonCdProperty().get());
			pstmt.setString(7, e.seibetsuProperty().get());
			pstmt.setString(8, e.ketsuekiGataProperty().get());
			pstmt.setDate(9, e.birthDateProperty().get() != null ? Date.valueOf(e.birthDateProperty().get()) : null);
			pstmt.setDate(10, Date.valueOf(LocalDate.now()));
			pstmt.setDate(11, null);

			pstmt.executeUpdate();
			logger.info("Insert successed: " + e.shainNoProperty().get());
		} catch (SQLException ex) {
			logger.error("insertEmployee() SQLException: " + ex);
			ex.printStackTrace();
		}
	}

	/**
	 * すべての従業員情報をデータベースから削除します。
	 */
	public void deleteAllEmployees() {
		String query = "DELETE FROM employees";

		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			
			pstmt.executeUpdate();
			
			logger.info("deleteAllEmployees()");
		} catch (SQLException ex) {
			logger.error("deleteAllEmployees() SQLException: " + ex);
			ex.printStackTrace();
		}
	}

	/**
	 * 指定した従業員をデータベースから削除します。
	 * 
	 * @param shainNo 従業員番号
	 */
	public void deleteEmployee(int shainNo) {
		String query = "DELETE FROM employees WHERE shain_no = ?";

		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setInt(1, shainNo);
			pstmt.executeUpdate();

			logger.info("Delete successed: " + shainNo);
		} catch (SQLException ex) {
			logger.error("deleteEmployee() SQLException: " + ex);
			ex.printStackTrace();
		}
	}

	/**
	 * 既存の従業員情報を更新します。
	 * 
	 * @param employee 更新する従業員情報
	 */
	public void updateEmployee(EmployeeDAO employee) {
		String query = "UPDATE employees SET shimei_kana = ?, shimei = ?, shimei_eiji = ?, zaiseki_kb = ?, bumon_cd = ?, "
				+ "seibetsu = ?, ketsueki_gata = ?, birth_date = ?, \"update\" = ? WHERE shain_no = ?";

		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setString(1, employee.shimeiKanaProperty().get());
			pstmt.setString(2, employee.shimeiProperty().get());
			pstmt.setString(3, employee.shimeiEijiProperty().get());
			pstmt.setString(4, employee.zaisekiKbProperty().get());
			pstmt.setString(5, employee.bumonCdProperty().get());
			pstmt.setString(6, employee.seibetsuProperty().get());
			pstmt.setString(7, employee.ketsuekiGataProperty().get());
			pstmt.setDate(8,
					employee.birthDateProperty().get() != null ? Date.valueOf(employee.birthDateProperty().get())
							: null);
			pstmt.setDate(9, Date.valueOf(LocalDate.now()));
			pstmt.setInt(10, employee.shainNoProperty().get());

			pstmt.executeUpdate();
			logger.info("Update successed: " + employee.shainNoProperty().get());
		} catch (SQLException ex) {
			logger.error("UpdateEmployee() SQLException: " + ex);
			ex.printStackTrace();
		}
	}

}
