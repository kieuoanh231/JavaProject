package repository;

import javafx.beans.property.*;
import java.time.LocalDate;

public class EmployeeDAO {
	private final IntegerProperty shainNo = new SimpleIntegerProperty();
	private final StringProperty shimeiKana = new SimpleStringProperty();
	private final StringProperty shimei = new SimpleStringProperty();
	private final StringProperty shimeiEiji = new SimpleStringProperty();
	private final StringProperty zaisekiKb = new SimpleStringProperty();
	private final StringProperty bumonCd = new SimpleStringProperty();
	private final StringProperty seibetsu = new SimpleStringProperty();
	private final StringProperty ketsuekiGata = new SimpleStringProperty();
	private final ObjectProperty<LocalDate> birthDate = new SimpleObjectProperty<>();
	private final ObjectProperty<LocalDate> createDate = new SimpleObjectProperty<>();
	private final ObjectProperty<LocalDate> updateDate = new SimpleObjectProperty<>();

	// Constructor
	public EmployeeDAO() {
	}

	// Getter & Setter (Property Binding)
	public IntegerProperty shainNoProperty() {
		return shainNo;
	}

	public StringProperty shimeiKanaProperty() {
		return shimeiKana;
	}

	public StringProperty shimeiProperty() {
		return shimei;
	}

	public StringProperty shimeiEijiProperty() {
		return shimeiEiji;
	}

	public StringProperty zaisekiKbProperty() {
		return zaisekiKb;
	}

	public StringProperty bumonCdProperty() {
		return bumonCd;
	}

	public StringProperty seibetsuProperty() {
		return seibetsu;
	}

	public StringProperty ketsuekiGataProperty() {
		return ketsuekiGata;
	}

	public ObjectProperty<LocalDate> birthDateProperty() {
		return birthDate;
	}

	public ObjectProperty<LocalDate> createDateProperty() {
		return createDate;
	}

	public ObjectProperty<LocalDate> updateDateProperty() {
		return updateDate;
	}

	@Override
	public String toString() {
		return "shainNo=" + shainNo.get() + ", shimeiKana='" + shimeiKana.get() + '\'' + ", shimei='" + shimei.get()
				+ '\'' + ", shimeiEiji='" + shimeiEiji.get() + '\'' + ", zaisekiKb='" + zaisekiKb.get() + '\''
				+ ", bumonCd='" + bumonCd.get() + '\'' + ", seibetsu='" + seibetsu.get() + '\'' + ", ketsuekiGata='"
				+ ketsuekiGata.get() + '\'' + ", birthDate=" + birthDate.get() + ", createDate=" + createDate.get()
				+ ", updateDate=" + updateDate.get() + '}';
	}

}
