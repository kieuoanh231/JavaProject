package util;

import javax.swing.*;

public class DialogUtil {

	/**
	 * 情報メッセージダイアログを表示する。
	 * @param message 表示するメッセージ
	 * @param title ダイアログのタイトル
	 */
	public static void showMessage(String message, String title) {
		JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
	}

	/**
	 * エラーメッセージダイアログを表示する。
	 * @param message 表示するメッセージ
	 * @param title ダイアログのタイトル
	 */
	public static void showError(String message, String title) {
		JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * 警告メッセージダイアログを表示する。
	 * @param message 表示するメッセージ
	 * @param title ダイアログのタイトル
	 */
	public static void showWarning(String message, String title) {
		JOptionPane.showMessageDialog(null, message, title, JOptionPane.WARNING_MESSAGE);
	}

	/**
	 * ユーザーにYes/Noの確認ダイアログを表示し、選択結果を返す。
	 * @param message 表示するメッセージ
	 * @param title ダイアログのタイトル
	 * @return JOptionPane.YES_OPTION または JOptionPane.NO_OPTION
	 */
	public static int showConfirmDialog(String message, String title) {
		return JOptionPane.showConfirmDialog(null, message, title, JOptionPane.YES_NO_OPTION);
	}

	/**
	 * カスタムの確認ダイアログを表示し、ユーザーの選択結果を返す。
	 * "続行" (YES) または "中止" (NO) を選択可能。
	 * @param message 表示するメッセージ
	 * @param title ダイアログのタイトル
	 * @return JOptionPane.YES_OPTION または JOptionPane.NO_OPTION
	 */
	public static int showCustomConfirmDialog(String message, String title) {
		Object[] options = { "続行", "中止" }; 
		return JOptionPane.showOptionDialog(null, message, title, JOptionPane.YES_NO_OPTION,
				JOptionPane.INFORMATION_MESSAGE, null, options, 
				options[0] 
		);
	}

}