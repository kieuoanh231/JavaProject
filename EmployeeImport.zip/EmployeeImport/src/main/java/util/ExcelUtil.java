package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;
import java.util.function.BiConsumer;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.ConfigConstants;
import repository.*;

public class ExcelUtil {

	/**
	 * Excelファイルを読み込みます。 エラーがあればエラーメッセージをリストに追加し、ダイアログで表示します。
	 * 
	 * @param filePath 読み込むExcelファイルのパス
	 * @return EmployeeDAOオブジェクトのリスト
	 * @throws IOException 読み込み時のIOエラー
	 */
	public static List<EmployeeDAO> readExcel(String filePath) throws IOException {
		List<EmployeeDAO> employeeList = new ArrayList<>();
		List<String> errorMessages = new ArrayList<>();

		FileInputStream fis = new FileInputStream(filePath);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheetAt(0);

		int lastRowNum = sheet.getLastRowNum();
		System.out.println("lastRowNum " + lastRowNum);

		if (lastRowNum < 1) {
			workbook.close();
			fis.close();
			return employeeList;
		}

		Iterator<Row> rowIterator = sheet.iterator();

		// 最初の行（カラム名）をスキップする
		if (rowIterator.hasNext()) {
			rowIterator.next();
		}

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			int rowNum = row.getRowNum() + 1;
			// データがない行をスキップする
			if (isRowEmpty(row))
				continue;

			EmployeeDAO employee = new EmployeeDAO();

			// EmployeeDAOのセッターに列をマッピングする
			Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = getColumnMapping(errorMessages, rowNum);

			for (int columnIndex = 0; columnIndex < columnMapping.size(); columnIndex++) {
				Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
				columnMapping.getOrDefault(columnIndex, (emp, c) -> {
				}).accept(employee, cell);
			}

			employeeList.add(employee);
		}

		workbook.close();
		fis.close();

		// Dialogにすべてのチェックメッセージを表示する
		if (!errorMessages.isEmpty()) {
			DialogUtil.showMessage(String.join("\n", errorMessages), ConfigConstants.MESSAGE);
		}

		return employeeList;
	}

	/**
	 * Excelの各列とその対応する処理をマッピングします。 行番号とエラーメッセージを使用して、検証結果をエラーメッセージリストに追加します。
	 * 
	 * @param errorMessages エラーメッセージを追加するリスト
	 * @param rowNum        処理中の行番号
	 * @return 各列のインデックスに対応するBiConsumerを持つマップ
	 */
	private static Map<Integer, BiConsumer<EmployeeDAO, Cell>> getColumnMapping(List<String> errorMessages,
			int rowNum) {
		Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = new HashMap<>();
		List<String> listKubunTemp = Arrays.asList("A", "B", "C");
		List<String> listBumonTemp = Arrays.asList("A", "B", "C");
		List<String> listSeibetsuTemp = Arrays.asList("女性", "男性", "その他");
		List<String> listBloodTemp = Arrays.asList("A", "B", "O");
		System.out.println("rownum " + rowNum);
		columnMapping.put(0, (emp, cell) -> {
			if (ValidatorUtil.isNumeric(cell)) {
				if (ValidatorUtil.hasMoreThanFourDigits((int) cell.getNumericCellValue())) {
					errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_NO_OVER);
				}
				emp.shainNoProperty().set((int) cell.getNumericCellValue());
			} else {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_NOT_NUMBER);
				emp.shainNoProperty().set(0);
			}
		});

		columnMapping.put(1, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_FURIGANA_EMPTY);
			}

			else if (ValidatorUtil.isOver30Characters(cell)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_FURIGANA_OVER);
			}
			emp.shimeiKanaProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(2, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_NAME_EMPTY);
			} else if (ValidatorUtil.isOver30Characters(cell)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_NAME_OVER);
			}
			emp.shimeiProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(3, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_EIJI_EMPTY);
			} else if (ValidatorUtil.isOver40Characters(cell)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_EIJI_OVER);
			}

			emp.shimeiEijiProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(4, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell) || ValidatorUtil.isNotInList(cell, listKubunTemp)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_ZAISEKIKKUBUN_NOT_EXIST);
			}

			emp.zaisekiKbProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(5, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell) || ValidatorUtil.isNotInList(cell, listBumonTemp)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_BUMON_CODE_NOT_EXIST);
			}

			emp.bumonCdProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(6, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell) || ValidatorUtil.isNotInList(cell, listSeibetsuTemp)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_GENDER_NOT_EXIST);
			}

			emp.seibetsuProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(7, (emp, cell) -> {
			if (!ValidatorUtil.isNotEmpty(cell) || ValidatorUtil.isNotInList(cell, listBloodTemp)) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_BLOOD_TYPE_NOT_EXIST);
			}

			emp.ketsuekiGataProperty().set(ValidatorUtil.getStringValue(cell));
		});

		columnMapping.put(8, (emp, cell) -> {
			if (ValidatorUtil.isValidDateAndFormat(cell) == null) {
				errorMessages.add("EXCEL [行 " + rowNum + "] " + ConfigConstants.VALIDATE_BIRTHDATE);
			}

			emp.birthDateProperty().set(ValidatorUtil.isValidDateAndFormat(cell));
		});

		return columnMapping;
	}

	/**
	 * Excelの行が空であるかどうかを確認します。
	 * 
	 * @param row 確認する行。
	 * @return 行が空（すべてのセルが空白）であればtrue、それ以外の場合はfalse。
	 */
	private static boolean isRowEmpty(Row row) {
		if (row == null)
			return true;
		for (Cell cell : row) {
			if (cell.getCellType() != CellType.BLANK) {
				return false;
			}
		}
		return true;
	}

}
