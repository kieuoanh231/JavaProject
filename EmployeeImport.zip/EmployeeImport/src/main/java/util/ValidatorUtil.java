package util;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;

public class ValidatorUtil {

	/**
	 * セルが空でないかどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが空でない場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isCellNotEmpty(Cell cell) {
		return cell != null && cell.getCellType() != CellType.BLANK;
	}

	/**
	 * セルが数値型かどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが空でなく、数値型の場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isNumeric(Cell cell) {
		return isCellNotEmpty(cell) && cell.getCellType() == CellType.NUMERIC;
	}

	/**
	 * セルが文字列型かどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが空でなく、文字列型の場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isString(Cell cell) {
		return isCellNotEmpty(cell) && cell.getCellType() == CellType.STRING;
	}

	/**
	 * セルがブール型かどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが空でなく、ブール型の場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isBoolean(Cell cell) {
		return isCellNotEmpty(cell) && cell.getCellType() == CellType.BOOLEAN;
	}

	/**
	 * セルが空でなく、文字列型で、空白以外の文字が含まれているかどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが空でなく、文字列型で、空白以外の文字がある場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isNotEmpty(Cell cell) {
		return isCellNotEmpty(cell) && isString(cell) && !cell.getStringCellValue().trim().isEmpty();
	}

	/**
	 * 数値が4桁以上かどうかを確認します。
	 * 
	 * @param value チェックする数値
	 * @return 数値が10000以上の場合はtrue、それ以外の場合はfalse
	 */
	public static boolean hasMoreThanFourDigits(int value) {
		return value >= 10000;
	}

	/**
	 * セルの文字列が30文字以上かどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが文字列型で、文字列の長さが30文字を超える場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isOver30Characters(Cell cell) {
		return isString(cell) && cell.getStringCellValue().trim().length() > 30;
	}

	/**
	 * セルの文字列が40文字以上かどうかを確認します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが文字列型で、文字列の長さが40文字を超える場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isOver40Characters(Cell cell) {
		return isString(cell) && cell.getStringCellValue().trim().length() > 40;
	}

	/**
	 * セルの文字列が指定されたリストに含まれていないかどうかを確認します。
	 * 
	 * @param cell        チェックするセル
	 * @param validValues 有効な値のリスト
	 * @return セルが文字列型で、指定されたリストに含まれていない場合はtrue、それ以外の場合はfalse
	 */
	public static boolean isNotInList(Cell cell, List<String> validValues) {
		return isString(cell) && !validValues.contains(cell.getStringCellValue().trim());
	}

	/**
	 * セルの値が有効な日付形式かどうかを確認し、日付をLocalDate型で返します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが有効な日付の場合はLocalDateを返し、そうでない場合はnull
	 */
	public static LocalDate isValidDateAndFormat(Cell cell) {
		if (!isCellNotEmpty(cell)) {
			return null;
		}
		if (isNumeric(cell) && DateUtil.isCellDateFormatted(cell)) {
			return cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		}
		return null;
	}

	/**
	 * セルの値を文字列として取得します。
	 * 
	 * @param cell チェックするセル
	 * @return セルが空でない場合、その値を文字列として返し、空の場合は空文字列を返す
	 */
	public static String getStringValue(Cell cell) {
		if (!isCellNotEmpty(cell))
			return "";
		if (isString(cell)) {
			return cell.getStringCellValue().trim();
		}
		if (isNumeric(cell)) {
			return String.valueOf((int) cell.getNumericCellValue());
		}
		if (isBoolean(cell)) {
			return String.valueOf(cell.getBooleanCellValue());
		}
		return "";
	}

}
