package util;

import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class LoadingHandler {

	private Region overlay;
	private ImageView successIcon;
	private ProgressIndicator progressIndicator;
	private Label statusLabelExe;
	private AnchorPane rootPane;

	public LoadingHandler(AnchorPane rootPane, ProgressIndicator progressIndicator, Label statusLabelExe) {
		this.rootPane = rootPane;
		this.progressIndicator = progressIndicator;
		this.statusLabelExe = statusLabelExe;
	}

	public void showLoading() {
		if (overlay == null) {
			overlay = new Region();
			overlay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.1);");
			overlay.setPrefSize(rootPane.getWidth(), rootPane.getHeight());
			rootPane.getChildren().add(overlay);
		}
		overlay.setVisible(true);
		progressIndicator.setVisible(true);
		statusLabelExe.setText("処理中...");
	}

	public void showSuccess() {
		progressIndicator.setVisible(false);
		overlay.setVisible(false);
		if (successIcon == null) {
			successIcon = new ImageView(new Image(getClass().getResourceAsStream("/images/check.png")));
			successIcon.setFitWidth(50);
			successIcon.setFitHeight(50);
			rootPane.getChildren().add(successIcon);
		}
		successIcon.setVisible(true);
		statusLabelExe.setText("✅ 完了しました！");
	}

	public void hideLoading() {
		rootPane.setVisible(false);
		rootPane.setDisable(true);
		progressIndicator.setVisible(false);
		overlay.setVisible(false);
	}

	public void hideSuccess() {
		if (successIcon != null) {
			successIcon.setVisible(false);
		}
		statusLabelExe.setText("");
	}
}
