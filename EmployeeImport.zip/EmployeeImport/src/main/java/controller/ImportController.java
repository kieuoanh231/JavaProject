package controller;

import java.io.File;
import java.sql.Connection;
import java.util.List;

import javax.swing.JOptionPane;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import config.ConfigConstants;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.EmployeeViewModel;
import repository.EmployeeDAO;
import util.DatabaseConnection;
import util.DialogUtil;
import util.ExcelUtil;
import util.LoadingHandler;

public class ImportController {

	@FXML
	private TextField txtField;

	@FXML
	private Button finishBtn;

	@FXML
	private Button browseBtn;

	@FXML
	private Button runBtn;

	@FXML
	private RadioButton addRadio;

	@FXML
	private RadioButton add_updateRadio;

	@FXML
	private RadioButton replaceRadio;

	private ToggleGroup toggleGroup;

	private Stage stage;

	@FXML
	private Accordion accordion1;

	@FXML
	private Accordion accordion2;

	@FXML
	private TitledPane titledPane1;

	@FXML
	private TitledPane titledPane2;

	@FXML
	private Button executeButton;

	@FXML
	private ProgressIndicator progressIndicator;

	@FXML
	private Label statusLabelExe;

	@FXML
	private AnchorPane rootPane;

	public static int addCount;

	public static int updateCount;

	private static final Logger logger = LogManager.getLogger(ImportController.class);

	private LoadingHandler loadingHandler;

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	/**
	 * 初期化メソッド。
	 */
	@FXML
	public void initialize() {
		toggleGroup = new ToggleGroup();
		addRadio.setToggleGroup(toggleGroup);
		add_updateRadio.setToggleGroup(toggleGroup);
		replaceRadio.setToggleGroup(toggleGroup);

		accordion1.setExpandedPane(titledPane1);
		accordion2.setExpandedPane(titledPane2);

		rootPane.setVisible(false);
		loadingHandler = new LoadingHandler(rootPane, progressIndicator, statusLabelExe);
	}

	/**
	 * 終了ボタンの処理。
	 */
	@FXML
	private void handleFinishBtnAction() {
		if (DialogUtil.showConfirmDialog("プログラムの終了を確認してください", "確認") == 0) {
			Platform.exit();
		}
	}

	/**
	 * ファイル選択ボタンの処理。
	 */
	@FXML
	private void handleBrowseBtnAction() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Excelファイルを選択してください");

		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Files", "*.xlsx", "*.xls"));
		File selectedFile = fileChooser.showOpenDialog(stage);
		try {
			if (selectedFile.exists() && selectedFile.getAbsolutePath() != null) {
				txtField.setText(selectedFile.getAbsolutePath());
			}
		} catch (Exception e) {
			txtField.setText(null);
			logger.error("handleBrowseBtnAction() Exception : " + e);
		}

	}

	/**
	 * 実行ボタンの処理。Excelデータをデータベースへ追加・更新・置換する。
	 */
	@FXML
	private void handleRunBtnAction() {
		if (runBtn.isDisabled()) {
			return;
		}
		if (DialogUtil.showCustomConfirmDialog("処理を続行しますか？", "確認") == JOptionPane.YES_OPTION) {
//			runBtn.setDisable(true);
//			rootPane.setVisible(true);
//			loadingHandler.showLoading();

			Task<Void> task = new Task<>() {
				@Override
				protected Void call() throws Exception {
					Connection conn = DatabaseConnection.getConnection();
					EmployeeViewModel employeeViewModel = new EmployeeViewModel();

					try {
						String filePath = txtField.getText();

						if (filePath == null || filePath.trim().isEmpty()) {
							Platform.runLater(() -> {
//								loadingHandler.hideLoading();
								Timeline timeline = new Timeline(new KeyFrame(Duration.millis(200), e -> {
									DialogUtil.showMessage(ConfigConstants.VALIDATE_PATH_EMPTY,
											ConfigConstants.MESSAGE);
								}));
								timeline.setCycleCount(1);
								timeline.play();
//								runBtn.setDisable(false);
							});
							return null;
						}

						File file = new File(filePath);
						if (!file.exists() || !file.isFile()) {
							Platform.runLater(() -> {
								loadingHandler.hideLoading();
								Timeline timeline = new Timeline(new KeyFrame(Duration.millis(200), e -> {
									DialogUtil.showMessage(ConfigConstants.VALIDATE_NOT_EXIST_FILE,
											ConfigConstants.MESSAGE);
								}));
								timeline.setCycleCount(1);
								timeline.play();
								runBtn.setDisable(false);
							});
							return null;
						}

						List<EmployeeDAO> excelList = ExcelUtil.readExcel(filePath);

						Toggle selectedToggle = toggleGroup.getSelectedToggle();
						if (selectedToggle != null) {
							RadioButton selectedRadio = (RadioButton) selectedToggle;
							if (conn != null) {
								switch (selectedRadio.getId()) {
								case "addRadio":
									addCount = 0;
									if (excelList != null) {
										employeeViewModel.compareAndAddEmployees(excelList);
									}
//									loadingHandler.hideLoading();
//									runBtn.setDisable(false);
									DialogUtil.showMessage("追加の件数：　" + addCount, ConfigConstants.MESSAGE);
									break;
								case "add_updateRadio":
									addCount = 0;
									updateCount = 0;
									if (excelList != null) {
										employeeViewModel.addAndUpdateEmployees(excelList);
									}
									DialogUtil.showMessage("追加の件数：　" + addCount + "\n更新の件数：　" + updateCount,
											ConfigConstants.MESSAGE);
									break;
								case "replaceRadio":
									addCount = 0;
									employeeViewModel.deleteAllEmployee();
									if (excelList != null) {
										employeeViewModel.replaceEmployees(excelList);
									}
									DialogUtil.showMessage("全件消除後の追加の件数：　" + addCount, ConfigConstants.MESSAGE);
									break;
								default:
									break;
								}
							} else {
								Platform.runLater(() -> {
									logger.error("handleRunBtnAction() connectDB failed!");
//									loadingHandler.hideLoading();
								});
							}
						}
					} catch (Exception e) {
						Platform.runLater(() -> {
							logger.error("handleRunBtnAction() Exception: " + e);
							loadingHandler.hideLoading();
						});
					}
					return null;
				}

				@Override
				protected void succeeded() {
					Platform.runLater(() -> {
//						loadingHandler.showSuccess();
						new Thread(() -> {
							try {
								Thread.sleep(200);
								Platform.runLater(() -> loadingHandler.hideSuccess());
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}).start();
						runBtn.setDisable(false); // Enable the button after operation
					});
				}

				@Override
				protected void failed() {
					Platform.runLater(() -> {
						loadingHandler.hideLoading();
//						runBtn.setDisable(false); // Enable the button after operation
					});
				}
			};

			new Thread(task).start();
		}
	}

}
