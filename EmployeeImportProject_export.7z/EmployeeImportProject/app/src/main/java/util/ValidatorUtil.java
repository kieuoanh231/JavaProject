package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;

public class ValidatorUtil {
	public static boolean isCellNotEmpty(Cell cell) {
		return cell != null && cell.getCellType() != CellType.BLANK;
	}

	public static boolean isNumeric(Cell cell) {
		return isCellNotEmpty(cell) && cell.getCellType() == CellType.NUMERIC;
	}

	public static boolean isString(Cell cell) {
		return isCellNotEmpty(cell) && cell.getCellType() == CellType.STRING;
	}

	public static boolean hasMoreThanFourDigits(int value) {
		return value >= 10000;
	}

	public static boolean isOver30Characters(Cell cell) {
		return isString(cell) && cell.getStringCellValue().trim().length() > 30;
	}

	public static boolean isOver40Characters(Cell cell) {
		return isString(cell) && cell.getStringCellValue().trim().length() > 40;

	}

	public static boolean isNotInList(Cell cell, List<String> validValues) {
		return isString(cell) && !validValues.contains(cell.getStringCellValue().trim());
	}

	public static boolean isValidDate(Cell cell) {
		if (!isCellNotEmpty(cell)) {
			return false;
		}

		if (isNumeric(cell)) {
			if (DateUtil.isCellDateFormatted(cell)) {
				Date date = cell.getDateCellValue();
				return date != null;
			}
		} else if (isString(cell)) {
			String dateStr = cell.getStringCellValue().trim();
			return isValidDateString(dateStr);
		}

		return false;
	}

	private static boolean isValidDateString(String dateStr) {
		if (dateStr == null || dateStr.isEmpty()) {
			return false;
		}

		String[] dateFormats = { "yyyy/MM/dd", "dd/MM/yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "dd-MM-yyyy" };

		for (String format : dateFormats) {
			if (isDateParsable(dateStr, format)) {
				return true;
			}
		}
		
		return false;
	}

	private static boolean isDateParsable(String dateStr, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false); // Không cho phép ngày không hợp lệ như 02/30
		try {
			sdf.parse(dateStr);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

}
