package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.ConfigConstants;
import repository.EmployeeDAO;

public class ExcelUtil {
	private static boolean hasError = false;

	public static List<EmployeeDAO> readExcel(String filePath) throws IOException {
		hasError = false;
		List<EmployeeDAO> listExcel = new ArrayList<>();

		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = createWorkbook(fis, filePath);
		Sheet sh = wb.getSheetAt(0);
		if (isSheetEmpty(sh)) {
			DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_EMPTY_SHEET, ConfigConstants.MESSAGE);
			return listExcel;
		}

		for (int rowIndex = 1; rowIndex < sh.getLastRowNum(); rowIndex++) {
			Row row = sh.getRow(rowIndex);
			Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = getColumnMapping(row.getRowNum() + 1);

			EmployeeDAO employeeDAO = new EmployeeDAO();

			if (getShainNoDuplicateInColumn(sh, row) != null && !getShainNoDuplicateInColumn(sh, row).isEmpty()) {
				List<Integer> listDuplicate = getShainNoDuplicateInColumn(sh, row);
				listDuplicate.add(row.getRowNum() + 1);
				listDuplicate.sort(Integer::compareTo);

				int maxDisplay = 5;
				String result = listDuplicate.stream().limit(maxDisplay).map(String::valueOf)
						.collect(Collectors.joining(" , "));

				if (listDuplicate.size() > maxDisplay) {
					result += " + ...";
				}

				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_DUPLICATE + "\n「行番号: " + result + "」",
						ConfigConstants.MESSAGE);

				return listExcel;
			} else {
				for (int columnIndex = 0; columnIndex < columnMapping.size(); columnIndex++) {
					if (hasError) {
						return listExcel;
					}
					Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
					columnMapping.getOrDefault(columnIndex, (emp, c) -> {
					}).accept(employeeDAO, cell);
				}
			}

			listExcel.add(employeeDAO);
		}

		return listExcel;
	}

	private static Map<Integer, BiConsumer<EmployeeDAO, Cell>> getColumnMapping(int rowNum) {
		Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = new HashMap<>();
		List<String> kubunListTemp = Arrays.asList("A", "B", "C");
		List<String> bumonListTemp = Arrays.asList("A", "B", "C");
		List<String> seibetsuListTemp = Arrays.asList("女性", "男性", "その他");
		List<String> bloodListTemp = Arrays.asList("A", "B", "O");

		columnMapping.put(0, (emp, cell) -> {
			if (!ValidatorUtil.isNumeric(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NOT_NUMBER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.hasMoreThanFourDigits((int) cell.getNumericCellValue())) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NO_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShainNo((int) cell.getNumericCellValue());
		});

		columnMapping.put(1, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimeiKana(cell.getStringCellValue());
		});

		columnMapping.put(2, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimei(cell.getStringCellValue());
		});

		columnMapping.put(3, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver40Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimeiEiji(cell.getStringCellValue());
		});

		columnMapping.put(4, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, kubunListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_ZAISEKIKUBUN_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setZaisekiKb(cell.getStringCellValue());
		});

		columnMapping.put(5, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bumonListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BUMON_CODE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setBumonCd(cell.getStringCellValue());
		});

		columnMapping.put(6, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, seibetsuListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_GENDER_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setSeibetsu(cell.getStringCellValue());
		});

		columnMapping.put(7, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bloodListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BLOOD_TYPE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setKetsuekiGata(cell.getStringCellValue());
		});

		columnMapping.put(8, (emp, cell) -> {
			if (!ValidatorUtil.isValidDate(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BIRTHDATE,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setBirthDate(cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		});

		return columnMapping;
	}

	private static Workbook createWorkbook(FileInputStream fis, String filePath) throws IOException {
		if (filePath.endsWith(".xlsx")) {
			return new XSSFWorkbook(fis); // Excel 2007 以上
		} else if (filePath.endsWith(".xls")) {
			return new HSSFWorkbook(fis); // Excel 97-2003
		} else {
			throw new IllegalArgumentException("Định dạng file không hợp lệ: " + filePath);
		}
	}

	public static Object getCellValue(Cell cell) {
		if (cell == null)
			return null;

		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue().trim();
		case NUMERIC:
			return (int) cell.getNumericCellValue();
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case FORMULA:
			return cell.getCellFormula();
		case BLANK:
		default:
			return null;
		}
	}

	private static List<Integer> getShainNoDuplicateInColumn(Sheet sheet, Row currentRow) {
		List<Integer> shainNoDuplicateList = new ArrayList<>();

		int currentRowNum = currentRow.getRowNum();
		if (currentRowNum <= 1) {
			return null;
		}

		Cell currentCell = currentRow.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

		int lastRowNum = sheet.getLastRowNum();
		for (int i = 1; i < lastRowNum; i++) {
			if (i == currentRowNum) {
				continue;
			}

			Row previousRow = sheet.getRow(i);
			Cell previousCell = previousRow.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
			System.out.println(getCellValue(currentCell));
			if (getCellValue(currentCell) != null && getCellValue(previousCell) != null
					&& getCellValue(currentCell).equals(getCellValue(previousCell))) {
				shainNoDuplicateList.add(previousRow.getRowNum() + 1);
			}

		}

		return shainNoDuplicateList;
	}

	private static boolean isSheetEmpty(Sheet sheet) {
		if (sheet == null) {
			return true;
		}

		for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			Row row = sheet.getRow(rowIndex);
			if (row != null && !isRowEmpty(row)) {
				return false;
			}
		}
		return true;
	}

	private static boolean isRowEmpty(Row row) {
		for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
			Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
			if (cell.getCellType() != CellType.BLANK) {
				if (cell.getCellType() == CellType.STRING && !cell.getStringCellValue().trim().isEmpty()) {
					return false;
				}

				if (cell.getCellType() != CellType.STRING) {
					return false;
				}
			}
		}
		return true;
	}

	public static void exportToExcel(List<EmployeeDAO> data) {
		File file = new File("exported_data.xlsx");
		System.err.println(file.getAbsolutePath());
		try (Workbook workbook = new XSSFWorkbook(); FileOutputStream fileOut = new FileOutputStream(file)) {
			Sheet sheet = workbook.createSheet("Data");
			Row header = sheet.createRow(0);
			header.createCell(0).setCellValue("ShainNo");
			header.createCell(1).setCellValue("Shimei");

			int rowIndex = 1;
			for (EmployeeDAO person : data) {
				Row row = sheet.createRow(rowIndex++);
				row.createCell(0).setCellValue(person.getShainNo());
				row.createCell(1).setCellValue(person.getShimei());
			}

			workbook.write(fileOut);
			DialogUtil.showInfoMessage("Export Successful", "File saved as exported_data.xlsx.");
		} catch (IOException ex) {
			DialogUtil.showErrorMessage("Error", "Failed to export data.");
		}
	}

}
