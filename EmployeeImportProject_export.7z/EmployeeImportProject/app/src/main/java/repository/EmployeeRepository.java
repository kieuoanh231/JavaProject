package repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class EmployeeRepository {

	public List<EmployeeDAO> getAllEmployees() {
		List<EmployeeDAO> employees = new ArrayList<EmployeeDAO>();
		String query = "SELECT * FROM employees";

		try (Connection conn = DBConnection.getConnection();
				Statement statement = conn.createStatement();
				ResultSet rs = statement.executeQuery(query)) {

			while (rs.next()) {
				EmployeeDAO employee = new EmployeeDAO();
				employee.setShainNo(rs.getInt("shain_no"));
				employee.setShimeiKana(rs.getString("shimei_kana"));
				employee.setShimei(rs.getString("shimei"));
				employee.setShimeiEiji(rs.getString("shimei_eiji"));
				employee.setZaisekiKb(rs.getString("zaiseki_kb"));
				employee.setBumonCd(rs.getString("bumon_cd"));
				employee.setSeibetsu(rs.getString("seibetsu"));
				employee.setKetsuekiGata(rs.getString("ketsueki_gata"));
				employee.setBirthDate(rs.getDate("birth_date") != null ? rs.getDate("birth_date").toLocalDate() : null);
				employee.setCreate(rs.getDate("create") != null ? rs.getDate("create").toLocalDate() : null);
				employee.setCreate(rs.getDate("update") != null ? rs.getDate("update").toLocalDate() : null);

				employees.add(employee);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return employees;
		}

		return employees;

	}

	public void insertEmployee(EmployeeDAO employeeDAO) {
		String query = "INSERT INTO employees (shain_no, shimei_kana, shimei, shimei_eiji, zaiseki_kb, bumon_cd, seibetsu, ketsueki_gata, birth_date, \"create\") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn.prepareStatement(query)) {
			preparedStatement.setInt(1, employeeDAO.getShainNo());
			preparedStatement.setString(2, employeeDAO.getShimeiKana());
			preparedStatement.setString(3, employeeDAO.getShimei());
			preparedStatement.setString(4, employeeDAO.getShimeiEiji());
			preparedStatement.setString(5, employeeDAO.getZaisekiKb());
			preparedStatement.setString(6, employeeDAO.getBumonCd());
			preparedStatement.setString(7, employeeDAO.getSeibetsu());
			preparedStatement.setString(8, employeeDAO.getKetsuekiGata());
			preparedStatement.setDate(9,
					employeeDAO.getBirthDate() != null ? Date.valueOf(employeeDAO.getBirthDate()) : null);
			preparedStatement.setDate(10, Date.valueOf(LocalDate.now()));

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void updateEmployee(EmployeeDAO employeeDAO) {
		String query = "UPDATE employees SET shimei_kana = ?, shimei = ?, shimei_eiji = ?, zaiseki_kb = ?, bumon_cd = ?, "
				+ "seibetsu = ?, ketsueki_gata = ?, birth_date = ?, \"update\" = ? WHERE shain_no = ?";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstm = conn.prepareStatement(query)) {

			pstm.setString(1, employeeDAO.getShimeiKana());
			pstm.setString(2, employeeDAO.getShimei());
			pstm.setString(3, employeeDAO.getShimeiEiji());
			pstm.setString(4, employeeDAO.getZaisekiKb());
			pstm.setString(5, employeeDAO.getBumonCd());
			pstm.setString(6, employeeDAO.getSeibetsu());
			pstm.setString(7, employeeDAO.getKetsuekiGata());
			pstm.setDate(8, employeeDAO.getBirthDate() != null ? Date.valueOf(employeeDAO.getBirthDate()) : null);
			pstm.setDate(9, Date.valueOf(LocalDate.now()));
			pstm.setInt(10, employeeDAO.getShainNo());

			pstm.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void deleteAllEmployees() {
		String query = "DELETE FROM employees";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstm = conn.prepareStatement(query)) {
			pstm.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void deleteEmployee(int shainNo) {
		String query = "DELETE FROM employees WHERE shain_no = ?";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setInt(1, shainNo);
			pstmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
