package model;

import java.util.List;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import repository.EmployeeDAO;
import repository.EmployeeRepository;

public class EmployeeViewModel {
	private EmployeeDAO employeeDAO;
	private final EmployeeRepository employeeRepository;
	private final ObservableList<EmployeeDAO> employeeList = FXCollections.observableArrayList();
	private int addCount = 0;
	private int updateCount = 0;

	public EmployeeViewModel() {
		this.employeeDAO = new EmployeeDAO();
		this.employeeRepository = new EmployeeRepository();
		loadEmployees();
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public int getAddCount() {
		return this.addCount;
	}

	public int getUpdateCount() {
		return this.updateCount;
	}

	public IntegerProperty shainNoProperty() {
		return employeeDAO.shainNoProperty();
	}

	public StringProperty shimeiKanaProperty() {
		return employeeDAO.shimeiKanaProperty();
	}

	public StringProperty shimeiProperty() {
		return employeeDAO.shimeiProperty();
	}

	public StringProperty shimeiEijiProperty() {
		return employeeDAO.shimeiEijiProperty();
	}

	public StringProperty zaisekiKbProperty() {
		return employeeDAO.zaisekiKbProperty();
	}

	public StringProperty bumonCdProperty() {
		return employeeDAO.bumonCdProperty();
	}

	public StringProperty seibetsuProperty() {
		return employeeDAO.seibetsuProperty();
	}

	public StringProperty ketsuekiGataProperty() {
		return employeeDAO.ketsuekiGataProperty();
	}

	public void loadEmployees() {
		employeeList.setAll(employeeRepository.getAllEmployees());
	}

	public ObservableList<EmployeeDAO> getEmployeeList() {
		return employeeList;
	}

	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void addEmployee() {
		employeeRepository.insertEmployee(employeeDAO);
		loadEmployees();
	}

	public void addEmployees(List<EmployeeDAO> excelList) {
		for (EmployeeDAO employeeDAO : excelList) {
			employeeRepository.insertEmployee(employeeDAO);
			addCount++;
		}
		loadEmployees();
	}

	public void compareAndAddEmployee(List<EmployeeDAO> excelList) {
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();
		for (EmployeeDAO excelEmployee : excelList) {
			boolean found = false;
			for (EmployeeDAO dbEmployee : dbList) {
				if (excelEmployee.getShainNo() == dbEmployee.getShainNo()) {
					found = true;
					break;
				}
			}

			if (!found) {
				employeeRepository.insertEmployee(excelEmployee);
				addCount++;
			}

		}

		loadEmployees();
	}

	public void updateEmployee() {
		employeeRepository.updateEmployee(employeeDAO);
		loadEmployees();
	}

	public void addAndUpdateEmployee(List<EmployeeDAO> excelList) {
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();
		for (EmployeeDAO excelEmployee : excelList) {
			boolean found = false;
			for (EmployeeDAO dbEmployee : dbList) {
				if (excelEmployee.getShainNo() == dbEmployee.getShainNo()) {
//					setEmployeeDAO(excelEmployee);
//					updateEmployee();
					employeeRepository.updateEmployee(excelEmployee);
					updateCount++;
					found = true;
					break;
				}
			}

			if (!found) {
				employeeRepository.insertEmployee(excelEmployee);
				addCount++;
			}

		}

		loadEmployees();
	}

	public void deleteAllEmployees() {
		employeeRepository.deleteAllEmployees();
		loadEmployees();
	}

	public void deleteEmployee() {
		employeeRepository.deleteEmployee(shainNoProperty().get());
		loadEmployees();
	}

}
