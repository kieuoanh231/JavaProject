package controller;

import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import config.ConfigConstants;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.EmployeeViewModel;
import repository.EmployeeDAO;
import util.DBConnection;
import util.DialogUtil;
import util.ExcelUtil;

public class ImportController {
	@FXML
	private Button finishBtn;

	@FXML
	private Button browseBtn;

	@FXML
	private Button exeBtn;

	@FXML
	private RadioButton add_rBtn;

	@FXML
	private RadioButton add_update_rBtn;

	@FXML
	private RadioButton replace_rBtn;

	@FXML
	private TextField txtPath;

	@FXML
	private Accordion accordion1;

	@FXML
	private Accordion accordion2;

	@FXML
	private TitledPane titlePane1;

	@FXML
	private TitledPane titlePane2;

	private ToggleGroup toggleGroup;

	private Stage stage;

	@FXML
	private Button exportBtn;

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	/**
	 * 初期化メソッド。
	 */
	@FXML
	public void initialize() {
		toggleGroup = new ToggleGroup();
		add_rBtn.setToggleGroup(toggleGroup);
		add_update_rBtn.setToggleGroup(toggleGroup);
		replace_rBtn.setToggleGroup(toggleGroup);

		accordion1.setExpandedPane(titlePane1);
		accordion2.setExpandedPane(titlePane2);
	}

	@FXML
	public void handleFinishBtnAction() {
		Platform.exit();
	}

	@FXML
	public void handleBrowseBtnAction() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Excelファイルを選択してください");

		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel files", "*.xlsx", "*.xls"));
		File selectedFile = fileChooser.showOpenDialog(stage);
		try {
			if (selectedFile.exists() && selectedFile.getAbsoluteFile() != null) {
				txtPath.setText(selectedFile.getAbsolutePath());
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@FXML
	public void handleExeButtonAction() {
		if (DialogUtil.showConfirmDialog(ConfigConstants.CONFIRM_EXECUTE, "確認") == 0) {
			try {
				String filePath = txtPath.getText();
				if (filePath == null || filePath.trim().isEmpty()) {
					DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_PATH_EMPTY, ConfigConstants.MESSAGE);
					return;
				}

				File file = new File(filePath);
				if (!file.exists() || !file.isFile()) {
					DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_PATH_EMPTY, ConfigConstants.MESSAGE);
					return;
				}

				List<EmployeeDAO> excelList = ExcelUtil.readExcel(filePath);

				Connection connection = DBConnection.getConnection();
				EmployeeViewModel employeeViewModel = new EmployeeViewModel();

				Toggle selectedToggle = toggleGroup.getSelectedToggle();
				RadioButton selectedRadio = (RadioButton) selectedToggle;
				if (connection != null) {
					switch (selectedRadio.getId()) {
					case "add_rBtn": {

						if (excelList != null && !excelList.isEmpty()) {
							employeeViewModel.compareAndAddEmployee(excelList);
						}

						DialogUtil.showErrorMessage("追加の件数：　" + employeeViewModel.getAddCount(),
								ConfigConstants.MESSAGE);
						break;
					}
					case "add_update_rBtn": {

						if (excelList != null && !excelList.isEmpty()) {
							employeeViewModel.addAndUpdateEmployee(excelList);
						}

						DialogUtil.showErrorMessage("追加の件数：　" + employeeViewModel.getAddCount() + "\n更新の件数：　"
								+ employeeViewModel.getUpdateCount(), ConfigConstants.MESSAGE);
						break;
					}
					case "replace_rBtn": {

						employeeViewModel.deleteAllEmployees();
						if (excelList != null && !excelList.isEmpty()) {
							employeeViewModel.addEmployees(excelList);
						}

						DialogUtil.showErrorMessage("全件消除後の追加の件数：　" + employeeViewModel.getAddCount(),
								ConfigConstants.MESSAGE);
						break;
					}
					default:
						throw new IllegalArgumentException("Unexpected value: " + selectedRadio.getId());
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e);
			}
		}
	}

	@FXML
	public void handleExportAction() {
		try {
			Connection conn = DBConnection.getConnection();
			EmployeeViewModel evm = new EmployeeViewModel();
			List<EmployeeDAO> employees = new ArrayList<EmployeeDAO>();

			if (conn != null) {
				employees = evm.getEmployeeList();
				if (employees != null) {
					ExcelUtil.exportToExcel(employees);
				}
			}
		} catch (Exception e) {
			System.err.println(e);
			// TODO: handle exception
		}
	}

}
