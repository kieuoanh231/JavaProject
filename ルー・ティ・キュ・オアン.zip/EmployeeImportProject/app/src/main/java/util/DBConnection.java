package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static final String url = "jdbc:postgresql://localhost:5432/employee_db";
	private static final String user = "postgres";
	private static final String password = "solekia";
	
	/**
	 * データベースへの接続を取得します。
	 * JDBCを使用してデータベースに接続し、接続オブジェクトを返します。
	 * 
	 * @return データベース接続のConnectionオブジェクト。接続に失敗した場合はnullを返します。
	 */
	public static Connection getConnection() {
		try {
			return DriverManager.getConnection(url,user,password);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
