package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.ConfigConstants;
import repository.EmployeeDAO;

public class ExcelUtil {
	private static boolean hasError = false;

	/**
	 * Excelファイルを読み取りします。
	 * 
	 * @param filePath 読み込むExcelファイルのパス。
	 * @return listExcel EmployeeDAOオブジェクトのリスト。
	 * @throws IOException ファイル読み込みエラー。
	 */
	public static List<EmployeeDAO> readExcel(String filePath) throws IOException {
		hasError = false;
		List<EmployeeDAO> listExcel = new ArrayList<>();

		// Excelファイルの読み込み
		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = createWorkbook(fis, filePath);
		Sheet sh = wb.getSheetAt(0);

		// シートが空かどうかをチェック
		if (isSheetEmpty(sh)) {
			DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_EMPTY_SHEET, ConfigConstants.MESSAGE);
			return listExcel;
		}

		// 行ごとのデータを処理
		for (int rowIndex = 1; rowIndex <= sh.getLastRowNum(); rowIndex++) {

			Row row = sh.getRow(rowIndex);
			if (isRowEmpty(row)) {
				continue; // 空の行をスキップ
			}

			Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = getColumnMapping(row.getRowNum() + 1);
			EmployeeDAO employeeDAO = new EmployeeDAO();

			// 重複する社員番号がある場合、エラーメッセージを表示
			List<Integer> duplicates = getShainNoDuplicateInColumn(sh, row);
			if (duplicates != null && !duplicates.isEmpty()) {
				List<Integer> listDuplicate = getShainNoDuplicateInColumn(sh, row);
				listDuplicate.add(row.getRowNum() + 1);
				listDuplicate.sort(Integer::compareTo);

				int maxDisplay = 5;
				String result = listDuplicate.stream().limit(maxDisplay).map(String::valueOf)
						.collect(Collectors.joining(" , "));

				if (listDuplicate.size() > maxDisplay) {
					result += " + ...";
				}

				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_DUPLICATE + "\n「行番号: " + result + "」",
						ConfigConstants.MESSAGE);

				return listExcel;
			} else {
				// 各列のデータをマッピングしてemployeeDAOにセット
				for (int columnIndex = 0; columnIndex < columnMapping.size(); columnIndex++) {

					if (hasError) {
						return listExcel;
					}
					Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
					columnMapping.getOrDefault(columnIndex, (emp, c) -> {
					}).accept(employeeDAO, cell);
				}
			}

			listExcel.add(employeeDAO);
		}

		return listExcel;
	}

	/**
	 * Excelファイルの各列に対応する処理をマッピングします。
	 * 
	 * @param rowNum 行番号。
	 * @return columnMapping 列インデックスと対応する処理のマッピング。
	 */
	private static Map<Integer, BiConsumer<EmployeeDAO, Cell>> getColumnMapping(int rowNum) {
		Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = new HashMap<>();
		List<String> kubunListTemp = Arrays.asList("A", "B", "C");
		List<String> bumonListTemp = Arrays.asList("A", "B", "C");
		List<String> seibetsuListTemp = Arrays.asList("女", "男", "その他");
		List<String> bloodListTemp = Arrays.asList("A", "B", "O", "AB");

		// 各列に対するバリデーションと処理
		columnMapping.put(0, (emp, cell) -> {
			if (!ValidatorUtil.isNumeric(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NOT_NUMBER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.hasMoreThanFourDigits((int) cell.getNumericCellValue())) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NO_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShainNo((int) cell.getNumericCellValue());
		});

		columnMapping.put(1, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimeiKana(cell.getStringCellValue());
		});

		columnMapping.put(2, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimei(cell.getStringCellValue());
		});

		columnMapping.put(3, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver40Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimeiEiji(cell.getStringCellValue());
		});

		columnMapping.put(4, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, kubunListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_ZAISEKIKUBUN_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setZaisekiKb(cell.getStringCellValue());
		});

		columnMapping.put(5, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bumonListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BUMON_CODE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setBumonCd(cell.getStringCellValue());
		});

		columnMapping.put(6, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, seibetsuListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_GENDER_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setSeibetsu(cell.getStringCellValue());
		});

		columnMapping.put(7, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bloodListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BLOOD_TYPE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setKetsuekiGata(cell.getStringCellValue());
		});

		columnMapping.put(8, (emp, cell) -> {
			if (ValidatorUtil.isValidDate(cell) == null) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BIRTHDATE,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setBirthDate(ValidatorUtil.isValidDate(cell));
		});

		return columnMapping;
	}

	/**
	 * Excelファイルの拡張子に応じて、適切なWorkbookオブジェクトを生成します。
	 * 
	 * @param fis      ExcelファイルのInputStream。
	 * @param filePath ファイルパス。
	 * @return Workbookオブジェクト（XSSFWorkbookまたはHSSFWorkbook）。
	 * @throws IOException ファイル読み込みエラー。
	 */
	private static Workbook createWorkbook(FileInputStream fis, String filePath) throws IOException {
		if (filePath.endsWith(".xlsx")) {
			return new XSSFWorkbook(fis); // Excel 2007 以上
		} else if (filePath.endsWith(".xls")) {
			return new HSSFWorkbook(fis); // Excel 97-2003
		} else {
			throw new IllegalArgumentException("Định dạng file không hợp lệ: " + filePath);
		}
	}

	/**
	 * セルの値を取得します。
	 * 
	 * @param cell セルオブジェクト。
	 * @return セルの値（String、int、booleanなど）。
	 */
	public static Object getCellValue(Cell cell) {
		if (cell == null)
			return null;

		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue().trim();
		case NUMERIC:
			return (int) cell.getNumericCellValue();
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case FORMULA:
			return cell.getCellFormula();
		case BLANK:
		default:
			return null;
		}
	}

	/**
	 * 同じ社員番号が列内に重複していないかをチェックします。
	 * 
	 * @param sheet      Excelのシート。
	 * @param currentRow 現在の行。
	 * @return shainNoDuplicateList 重複した社員番号の行番号リスト。
	 */
	private static List<Integer> getShainNoDuplicateInColumn(Sheet sheet, Row currentRow) {
		List<Integer> shainNoDuplicateList = new ArrayList<>();

		int currentRowNum = currentRow.getRowNum();
		if (currentRowNum <= 1) {
			return new ArrayList<>();
		}

		Cell currentCell = currentRow.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

		int lastRowNum = sheet.getLastRowNum();
		for (int i = 1; i <= lastRowNum; i++) {
			if (i == currentRowNum) {
				continue;
			}

			Row previousRow = sheet.getRow(i);
			if (previousRow == null)
				continue;

			Cell previousCell = previousRow.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

			if (getCellValue(currentCell) != null && getCellValue(currentCell).equals(getCellValue(previousCell))) {
				shainNoDuplicateList.add(i + 1);
			}

		}

		return shainNoDuplicateList;
	}

	/**
	 * シートが空かどうかをチェックします。
	 * 
	 * @param sheet チェックするシート。
	 * @return シートが空であればtrue、そうでなければfalse。
	 */
	private static boolean isSheetEmpty(Sheet sheet) {
		if (sheet == null) {
			return true;
		}

		for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			Row row = sheet.getRow(rowIndex);
			if (row != null && !isRowEmpty(row)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 行が空であるかどうかをチェックします。
	 * 
	 * @param row チェックする行。
	 * @return 行が空であればtrue、そうでなければfalse。
	 */
	private static boolean isRowEmpty(Row row) {
		for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
			Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
			if (cell.getCellType() != CellType.BLANK) {
				if (cell.getCellType() == CellType.STRING && !cell.getStringCellValue().trim().isEmpty()) {
					return false;
				}

				if (cell.getCellType() != CellType.STRING) {
					return false;
				}
			}
		}
		return true;
	}

}
