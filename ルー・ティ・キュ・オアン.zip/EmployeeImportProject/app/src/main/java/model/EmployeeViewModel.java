package model;

import java.util.List;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import repository.EmployeeDAO;
import repository.EmployeeRepository;

public class EmployeeViewModel {
	private EmployeeDAO employeeDAO;
	private final EmployeeRepository employeeRepository;
	private final ObservableList<EmployeeDAO> employeeList = FXCollections.observableArrayList();
	private int addCount = 0;
	private int updateCount = 0;

	public EmployeeViewModel() {
		this.employeeDAO = new EmployeeDAO();
		this.employeeRepository = new EmployeeRepository();
		loadEmployees();
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public int getAddCount() {
		return this.addCount;
	}

	public int getUpdateCount() {
		return this.updateCount;
	}

	public IntegerProperty shainNoProperty() {
		return employeeDAO.shainNoProperty();
	}

	public StringProperty shimeiKanaProperty() {
		return employeeDAO.shimeiKanaProperty();
	}

	public StringProperty shimeiProperty() {
		return employeeDAO.shimeiProperty();
	}

	public StringProperty shimeiEijiProperty() {
		return employeeDAO.shimeiEijiProperty();
	}

	public StringProperty zaisekiKbProperty() {
		return employeeDAO.zaisekiKbProperty();
	}

	public StringProperty bumonCdProperty() {
		return employeeDAO.bumonCdProperty();
	}

	public StringProperty seibetsuProperty() {
		return employeeDAO.seibetsuProperty();
	}

	public StringProperty ketsuekiGataProperty() {
		return employeeDAO.ketsuekiGataProperty();
	}

	/**
	 * データベースから全ての社員情報を取得して、リストにセットします。
	 */
	public void loadEmployees() {
		employeeList.setAll(employeeRepository.getAllEmployees());
	}

	/**
	 * 現在の社員リストを返します。
	 * 
	 * @return employeeList 社員リスト。
	 */
	public ObservableList<EmployeeDAO> getEmployeeList() {
		return employeeList;
	}

	/**
	 * 現在の社員データを取得します。
	 * 
	 * @return employeeDAO 現在の社員データ。
	 */
	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	/**
	 * データベースに新しい社員を追加します。
	 */
	public void addEmployee() {
		employeeRepository.insertEmployee(employeeDAO);
		loadEmployees();
	}

	/**
	 * データベースに複数の社員データを追加します。
	 * 
	 * @param excelList Excelから取得した社員データのリスト。
	 */
	public void addEmployees(List<EmployeeDAO> excelList) {
		for (EmployeeDAO employeeDAO : excelList) {
			if (employeeRepository.insertEmployee(employeeDAO)) {
				addCount++;
			}else {
                System.out.println("Insert failed for: " + employeeDAO.getShainNo());
            }
		}
		loadEmployees();
	}

	/**
	 * Excelから取得した社員データとデータベースの社員データを比較し、 存在しない社員のみをデータベースに追加します。
	 * 
	 * @param excelList Excelから取得した社員データのリスト。
	 */
	public void compareAndAddEmployee(List<EmployeeDAO> excelList) {
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();
		for (EmployeeDAO excelEmployee : excelList) {
			boolean found = false;
			for (EmployeeDAO dbEmployee : dbList) {
				if (excelEmployee.getShainNo() == dbEmployee.getShainNo()) {
					found = true;
					break;
				}
			}

			if (!found) {
				employeeRepository.insertEmployee(excelEmployee);
				addCount++;
			}

		}

		loadEmployees();
	}

	/**
	 * 社員データをデータベースで更新します。
	 */
	public void updateEmployee() {
		employeeRepository.updateEmployee(employeeDAO);
		loadEmployees();
	}

	/**
	 * Excelから取得した社員データを追加および更新します。 データベース内の社員データと照合し、存在する場合は更新し、存在しない場合は追加します。
	 * 
	 * @param excelList Excelから取得した社員データのリスト。
	 */
	public void addAndUpdateEmployee(List<EmployeeDAO> excelList) {
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();
		for (EmployeeDAO excelEmployee : excelList) {
			boolean found = false;
			for (EmployeeDAO dbEmployee : dbList) {
				if (excelEmployee.getShainNo() == dbEmployee.getShainNo()) {
//					setEmployeeDAO(excelEmployee);
//					updateEmployee();
					employeeRepository.updateEmployee(excelEmployee);
					updateCount++;
					found = true;
					break;
				}
			}

			if (!found) {
				employeeRepository.insertEmployee(excelEmployee);
				addCount++;
			}

		}

		loadEmployees();
	}

	/**
	 * 全ての社員データを削除します。
	 */
	public void deleteAllEmployees() {
		employeeRepository.deleteAllEmployees();
		loadEmployees();
	}

	/**
	 * 特定の社員データを削除します。
	 */
	public void deleteEmployee() {
		employeeRepository.deleteEmployee(shainNoProperty().get());
		loadEmployees();
	}

}
