package repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import util.DBConnection;

public class EmployeeRepository {
	private static final Logger logger = LogManager.getLogger(EmployeeRepository.class);

	/**
	 * データベースから全ての社員データを取得し、EmployeeDAOオブジェクトのリストとして返します。
	 * 
	 * @return employees 全ての社員データのリスト。
	 */
	public List<EmployeeDAO> getAllEmployees() {
		logger.info("Fetching all employees from database.");
		List<EmployeeDAO> employees = new ArrayList<EmployeeDAO>();
		String query = "SELECT * FROM employees";

		try (Connection conn = DBConnection.getConnection();
				Statement statement = conn.createStatement();
				ResultSet rs = statement.executeQuery(query)) {

			while (rs.next()) {
				EmployeeDAO employee = new EmployeeDAO();
				employee.setShainNo(rs.getInt("shain_no"));
				employee.setShimeiKana(rs.getString("shimei_kana"));
				employee.setShimei(rs.getString("shimei"));
				employee.setShimeiEiji(rs.getString("shimei_eiji"));
				employee.setZaisekiKb(rs.getString("zaiseki_kb"));
				employee.setBumonCd(rs.getString("bumon_cd"));
				employee.setSeibetsu(rs.getString("seibetsu"));
				employee.setKetsuekiGata(rs.getString("ketsueki_gata"));
				employee.setBirthDate(rs.getDate("birth_date") != null ? rs.getDate("birth_date").toLocalDate() : null);
				employee.setCreate(rs.getDate("create") != null ? rs.getDate("create").toLocalDate() : null);
				employee.setUpdate(rs.getDate("update") != null ? rs.getDate("update").toLocalDate() : null);
				employees.add(employee);
			}

		} catch (SQLException e) {
			logger.error("Failed to fetch employees from database", e);
		}

		return employees;

	}

	/**
	 * 新しい社員データをデータベースに挿入します。
	 * 
	 * @param employeeDAO 挿入する社員のデータ。
	 */
	public boolean insertEmployee(EmployeeDAO employeeDAO) {
		logger.info("Inserting employee with ID: {}", employeeDAO.getShainNo());
		String query = "INSERT INTO employees (shain_no, shimei_kana, shimei, shimei_eiji, zaiseki_kb, bumon_cd, seibetsu, ketsueki_gata, birth_date, \"create\") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn.prepareStatement(query)) {
			preparedStatement.setInt(1, employeeDAO.getShainNo());
			preparedStatement.setString(2, employeeDAO.getShimeiKana());
			preparedStatement.setString(3, employeeDAO.getShimei());
			preparedStatement.setString(4, employeeDAO.getShimeiEiji());
			preparedStatement.setString(5, employeeDAO.getZaisekiKb());
			preparedStatement.setString(6, employeeDAO.getBumonCd());
			preparedStatement.setString(7, employeeDAO.getSeibetsu());
			preparedStatement.setString(8, employeeDAO.getKetsuekiGata());
			preparedStatement.setDate(9,
					employeeDAO.getBirthDate() != null ? Date.valueOf(employeeDAO.getBirthDate()) : null);
			preparedStatement.setDate(10, Date.valueOf(LocalDate.now()));

			int rowsAffected = preparedStatement.executeUpdate();
			boolean success = rowsAffected > 0;
			if (success) {
				logger.info("Employee inserted successfully.");
			} else {
				logger.warn("Employee insertion affected 0 rows.");
			}
			return success;
		} catch (SQLException e) {
			logger.error("Failed to insert employee", e);
			return false;
		}
	}

	/**
	 * データベースに一度に複数の社員を追加します。
	 * 
	 * @param employeeDAOList 挿入する社員のリスト。
	 */
	public void insertEmployeesBatch(List<EmployeeDAO> employeeDAOList) {
		logger.info("Inserting batch of {} employees.", employeeDAOList.size());
		String query = "INSERT INTO employees (shain_no, shimei_kana, shimei, shimei_eiji, zaiseki_kb, bumon_cd, seibetsu, ketsueki_gata, birth_date, \"create\") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn.prepareStatement(query)) {

			for (EmployeeDAO employeeDAO : employeeDAOList) {
				preparedStatement.setInt(1, employeeDAO.getShainNo());
				preparedStatement.setString(2, employeeDAO.getShimeiKana());
				preparedStatement.setString(3, employeeDAO.getShimei());
				preparedStatement.setString(4, employeeDAO.getShimeiEiji());
				preparedStatement.setString(5, employeeDAO.getZaisekiKb());
				preparedStatement.setString(6, employeeDAO.getBumonCd());
				preparedStatement.setString(7, employeeDAO.getSeibetsu());
				preparedStatement.setString(8, employeeDAO.getKetsuekiGata());
				preparedStatement.setDate(9,
						employeeDAO.getBirthDate() != null ? Date.valueOf(employeeDAO.getBirthDate()) : null);
				preparedStatement.setDate(10, Date.valueOf(LocalDate.now()));

				preparedStatement.addBatch();
			}

			preparedStatement.executeBatch();
			logger.info("Batch insert completed.");
		} catch (SQLException e) {
			logger.error("Batch insert failed", e);
		}
	}

	/**
	 * 既存の社員データを更新します。
	 * 
	 * @param employeeDAO 更新する社員のデータ。
	 */
	public void updateEmployee(EmployeeDAO employeeDAO) {
		logger.info("Updating employee with ID: {}", employeeDAO.getShainNo());
		String query = "UPDATE employees SET shimei_kana = ?, shimei = ?, shimei_eiji = ?, zaiseki_kb = ?, bumon_cd = ?, "
				+ "seibetsu = ?, ketsueki_gata = ?, birth_date = ?, \"update\" = ? WHERE shain_no = ?";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstm = conn.prepareStatement(query)) {

			pstm.setString(1, employeeDAO.getShimeiKana());
			pstm.setString(2, employeeDAO.getShimei());
			pstm.setString(3, employeeDAO.getShimeiEiji());
			pstm.setString(4, employeeDAO.getZaisekiKb());
			pstm.setString(5, employeeDAO.getBumonCd());
			pstm.setString(6, employeeDAO.getSeibetsu());
			pstm.setString(7, employeeDAO.getKetsuekiGata());
			pstm.setDate(8, employeeDAO.getBirthDate() != null ? Date.valueOf(employeeDAO.getBirthDate()) : null);
			pstm.setDate(9, Date.valueOf(LocalDate.now()));
			pstm.setInt(10, employeeDAO.getShainNo());

			pstm.executeUpdate();
			logger.info("Employee updated successfully.");
		} catch (SQLException e) {
			logger.error("Failed to update employee", e);
		}

	}

	/**
	 * データベースに一度に複数の社員データを更新します。
	 * 
	 * @param employeeDAOList 更新する社員のリスト。
	 */
	public void updateEmployeesBatch(List<EmployeeDAO> employeeDAOList) {
		logger.info("Updating batch of {} employees.", employeeDAOList.size());
		String query = "UPDATE employees SET shimei_kana = ?, shimei = ?, shimei_eiji = ?, zaiseki_kb = ?, bumon_cd = ?, "
				+ "seibetsu = ?, ketsueki_gata = ?, birth_date = ?, \"update\" = ? WHERE shain_no = ?";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstm = conn.prepareStatement(query)) {

			for (EmployeeDAO employeeDAO : employeeDAOList) {
				pstm.setString(1, employeeDAO.getShimeiKana());
				pstm.setString(2, employeeDAO.getShimei());
				pstm.setString(3, employeeDAO.getShimeiEiji());
				pstm.setString(4, employeeDAO.getZaisekiKb());
				pstm.setString(5, employeeDAO.getBumonCd());
				pstm.setString(6, employeeDAO.getSeibetsu());
				pstm.setString(7, employeeDAO.getKetsuekiGata());
				pstm.setDate(8, employeeDAO.getBirthDate() != null ? Date.valueOf(employeeDAO.getBirthDate()) : null);
				pstm.setDate(9, Date.valueOf(LocalDate.now()));
				pstm.setInt(10, employeeDAO.getShainNo());

				pstm.addBatch();
			}

			pstm.executeBatch();
			logger.info("Batch update completed.");
		} catch (SQLException e) {
			logger.error("Batch update failed", e);
		}
	}

	/**
	 * データベース内の全社員を削除します。
	 */
	public void deleteAllEmployees() {
		logger.info("Deleting all employees from database.");
		String query = "DELETE FROM employees";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstm = conn.prepareStatement(query)) {
			pstm.executeUpdate();
			logger.info("All employees deleted successfully.");
		} catch (SQLException e) {
			logger.error("Failed to delete all employees", e);
		}

	}

	/**
	 * 特定の社員データを削除します。
	 * 
	 * @param shainNo 削除する社員の社員番号。
	 */
	public void deleteEmployee(int shainNo) {
		logger.info("Deleting employee with ID: {}", shainNo);
		String query = "DELETE FROM employees WHERE shain_no = ?";

		try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, shainNo);
			pstmt.executeUpdate();
			logger.info("Employee deleted successfully.");
		} catch (SQLException ex) {
			logger.error("Failed to delete employee", ex);
		}
	}

}
