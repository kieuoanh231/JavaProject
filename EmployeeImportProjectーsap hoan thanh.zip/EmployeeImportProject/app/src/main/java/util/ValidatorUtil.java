package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;

public class ValidatorUtil {

	/**
	 * セルが空でないかをチェックします。
	 * 
	 * @param cell チェックするセル。
	 * @return true または false。
	 */
	public static boolean isCellNotEmpty(Cell cell) {
		return cell != null && cell.getCellType() != CellType.BLANK;
	}

	/**
	 * セルが数値を含んでいるかをチェックします。
	 * 
	 * @param cell チェックするセル。
	 * @return true または false。
	 */
	public static boolean isNumeric(Cell cell) {
		if (!isCellNotEmpty(cell)) {
			return false;
		}

		CellType cellType = cell.getCellType();
		if (cellType == CellType.NUMERIC) {
			return true;
		} else if (cellType == CellType.STRING) {
			try {
				Double.parseDouble(cell.getStringCellValue());
				return true;
			} catch (NumberFormatException e) {
				return false;
			}
		} else if (cellType == CellType.FORMULA) {
			try {
				return cell.getCachedFormulaResultType() == CellType.NUMERIC;
			} catch (Exception e) {
				return false;
			}
		}
		return false;
	}

	/**
	 * セルが文字列を含んでいるかをチェックします。
	 * 
	 * @param cell チェックするセル。
	 * @return true または false。
	 */
	public static boolean isString(Cell cell) {
		return isCellNotEmpty(cell) && cell.getCellType() == CellType.STRING;
	}

	/**
	 * 数値が4桁以上かをチェックします。
	 * 
	 * @param value チェックする数値。
	 * @return true または false。
	 */
	public static boolean hasMoreThanFourDigits(int value) {
		return value >= 10000;
	}

	/**
	 * セル内の文字列が30文字を超えているかをチェックします。
	 * 
	 * @param cell チェックするセル。
	 * @return true または false。
	 */
	public static boolean isOver30Characters(Cell cell) {
		return isString(cell) && cell.getStringCellValue().trim().length() > 30;
	}

	/**
	 * セル内の文字列が40文字を超えているかをチェックします。
	 * 
	 * @param cell チェックするセル。
	 * @return true または false。
	 */
	public static boolean isOver40Characters(Cell cell) {
		return isString(cell) && cell.getStringCellValue().trim().length() > 40;

	}

	/**
	 * セル内の値が指定されたリストに含まれていないかをチェックします。
	 * 
	 * @param cell        チェックするセル。
	 * @param validValues 有効な値のリスト。
	 * @return true または false。
	 */
	public static boolean isNotInList(Cell cell, List<String> validValues) {
		return isString(cell) && !validValues.contains(cell.getStringCellValue().trim());
	}

	/**
	 * セルが有効な日付を含んでいるかをチェックします。
	 * 
	 * @param cell チェックするセル。
	 * @return セルが有効な日付を含んでいる場合はLocalDate、無効な場合はnull。
	 */
	public static LocalDate isValidDate(Cell cell) {
		if (!isCellNotEmpty(cell)) {
			return null;
		}

		if (isNumeric(cell)) {
			if (DateUtil.isCellDateFormatted(cell)) {
				Date date = cell.getDateCellValue();
				return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			}
		} else if (isString(cell)) {
			String dateStr = cell.getStringCellValue().trim();
			return isValidDateString(dateStr);
		}

		return null;
	}

	/**
	 * 文字列が指定された日付フォーマットで有効な日付かをチェックします。
	 * 
	 * @param dateStr チェックする日付文字列。
	 * @return 有効な日付文字列の場合はLocalDate、無効な場合はnull。
	 */
	private static LocalDate isValidDateString(String dateStr) {
		if (dateStr == null || dateStr.isEmpty()) {
			return null;
		}

		String[] dateFormats = { "yyyy/MM/dd", "dd/MM/yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "dd-MM-yyyy" };

		for (String format : dateFormats) {
			LocalDate parsedDate = isDateParsable(dateStr, format);
			if (parsedDate != null) {
				return parsedDate;
			}
		}

		return null;
	}

	/**
	 * 指定された日付フォーマットで文字列がパース可能かをチェックします。
	 * 
	 * @param dateStr チェックする日付文字列。
	 * @param format  日付フォーマット。
	 * @return 文字列が指定されたフォーマットで日付として有効であればLocalDate、無効であればnull。
	 */
	private static LocalDate isDateParsable(String dateStr, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);
		try {
			return sdf.parse(dateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		} catch (ParseException e) {
			return null;
		}
	}

}
