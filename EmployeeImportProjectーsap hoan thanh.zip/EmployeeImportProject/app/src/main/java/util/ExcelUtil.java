package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.ConfigConstants;
import repository.EmployeeDAO;

public class ExcelUtil {
	private static final Logger logger = LogManager.getLogger(ExcelUtil.class);
	public static boolean hasError = false;

	/**
	 * Excelファイルを読み取りします。
	 * 
	 * @param filePath 読み込むExcelファイルのパス。
	 * @return listExcel EmployeeDAOオブジェクトのリスト。
	 * @throws IOException ファイル読み込みエラー。
	 */
	public static List<EmployeeDAO> readExcel(String filePath) throws IOException {
		logger.info("Start reading Excel file: {}", filePath);
		hasError = false;
		List<EmployeeDAO> listExcel = new ArrayList<>();
		Set<Object> seenShainNos = new HashSet<>();
		Map<Object, List<Integer>> duplicateMap = new HashMap<>();

		try (FileInputStream fis = new FileInputStream(filePath); Workbook wb = createWorkbook(fis, filePath)) {
			Sheet sh = wb.getSheetAt(0);
			if (isSheetEmpty(sh)) {
				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_EMPTY_SHEET, ConfigConstants.MESSAGE);
				logger.warn("Empty sheet detected in file: {}", filePath);
				return listExcel;
			}

			for (int rowIndex = 1; rowIndex <= sh.getLastRowNum(); rowIndex++) {
				Row row = sh.getRow(rowIndex);
				Cell shainNoCell = row.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
				Object shainNo = getCellValue(shainNoCell);

				if (shainNo == null) {
					return listExcel;
				}

				if (!seenShainNos.add(shainNo)) {
					List<Integer> duplicateRows = duplicateMap.computeIfAbsent(shainNo, k -> new ArrayList<>());
					if (duplicateRows.isEmpty()) {
						for (int i = 1; i < rowIndex; i++) {
							Row previousRow = sh.getRow(i);
							if (previousRow == null)
								continue;
							Cell previousCell = previousRow.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
							Object previousShainNo = getCellValue(previousCell);
							if (shainNo.equals(previousShainNo)) {
								duplicateRows.add(i + 1);
								break;
							}
						}
					}
					duplicateRows.add(rowIndex + 1);
					continue;
				}

				Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = getColumnMapping(rowIndex + 1);
				EmployeeDAO employeeDAO = new EmployeeDAO();

				for (int columnIndex = 0; columnIndex < columnMapping.size(); columnIndex++) {
					if (hasError)
						return listExcel;
					Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
					columnMapping.getOrDefault(columnIndex, (emp, c) -> {
					}).accept(employeeDAO, cell);
				}

				listExcel.add(employeeDAO);

			}

			if (!duplicateMap.isEmpty()) {
				List<Integer> allDuplicateRows = duplicateMap.values().stream().flatMap(List::stream).sorted()
						.distinct().collect(Collectors.toList());

				int maxDisplay = 5;
				String result = allDuplicateRows.stream().limit(maxDisplay).map(String::valueOf)
						.collect(Collectors.joining(" , "));
				if (allDuplicateRows.size() > maxDisplay)
					result += " + ...";

				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_DUPLICATE + "\n「行番号: " + result + "」",
						ConfigConstants.MESSAGE);
				return new ArrayList<>();
			}

			return listExcel;
		} catch (IOException e) {
			logger.error("Error while reading Excel file: {}", filePath, e);
			throw e;
		}
	}

	/**
	 * Excelファイルの各列に対応する処理をマッピングします。
	 * 
	 * @param rowNum 行番号。
	 * @return columnMapping 列インデックスと対応する処理のマッピング。
	 */
	private static Map<Integer, BiConsumer<EmployeeDAO, Cell>> getColumnMapping(int rowNum) {
		Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = new HashMap<>();
		List<String> kubunListTemp = Arrays.asList("A", "B", "C");
		List<String> bumonListTemp = Arrays.asList("A", "B", "C");
		List<String> seibetsuListTemp = Arrays.asList("女", "男", "その他");
		List<String> bloodListTemp = Arrays.asList("A", "B", "O", "AB");

		// 各列に対するバリデーションと処理
		columnMapping.put(0, (emp, cell) -> {
			if (!ValidatorUtil.isNumeric(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NOT_NUMBER,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_NOT_NUMBER);
				hasError = true;
				return;
			}

			if (ValidatorUtil.hasMoreThanFourDigits((int) cell.getNumericCellValue())) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NO_OVER,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_NO_OVER);
				hasError = true;
				return;
			}

			emp.setShainNo((int) cell.getNumericCellValue());
		});

		columnMapping.put(1, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_EMPTY,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_FURIGANA_EMPTY);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_OVER,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_FURIGANA_OVER);
				hasError = true;
				return;
			}

			emp.setShimeiKana(getCellValue(cell).toString());
		});

		columnMapping.put(2, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_EMPTY,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_NAME_EMPTY);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_OVER,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_NAME_OVER);
				hasError = true;
				return;
			}

			emp.setShimei(getCellValue(cell).toString());
		});

		columnMapping.put(3, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_EMPTY,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_EIJI_EMPTY);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver40Characters(cell)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_OVER,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_EIJI_OVER);
				hasError = true;
				return;
			}

			emp.setShimeiEiji(getCellValue(cell).toString());
		});

		columnMapping.put(4, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, kubunListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_ZAISEKIKUBUN_NOT_EXIST,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum,
						ConfigConstants.VALIDATE_ZAISEKIKUBUN_NOT_EXIST);
				hasError = true;
				return;
			}

			emp.setZaisekiKb(getCellValue(cell).toString());
		});

		columnMapping.put(5, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bumonListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BUMON_CODE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_BUMON_CODE_NOT_EXIST);
				hasError = true;
				return;
			}

			emp.setBumonCd(getCellValue(cell).toString());
		});

		columnMapping.put(6, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, seibetsuListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_GENDER_NOT_EXIST,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_GENDER_NOT_EXIST);
				hasError = true;
				return;
			}

			emp.setSeibetsu(getCellValue(cell).toString());
		});

		columnMapping.put(7, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bloodListTemp)) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BLOOD_TYPE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_BLOOD_TYPE_NOT_EXIST);
				hasError = true;
				return;
			}

			emp.setKetsuekiGata(getCellValue(cell).toString());
		});

		columnMapping.put(8, (emp, cell) -> {
			if (ValidatorUtil.isValidDate(cell) == null) {
				DialogUtil.showErrorMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BIRTHDATE,
						ConfigConstants.MESSAGE);
				logger.error("Validation failed at row {}: {}", rowNum, ConfigConstants.VALIDATE_BIRTHDATE);
				hasError = true;
				return;
			}

			emp.setBirthDate(ValidatorUtil.isValidDate(cell));
		});

		return columnMapping;
	}

	/**
	 * Excelファイルの拡張子に応じて、適切なWorkbookオブジェクトを生成します。
	 * 
	 * @param fis      ExcelファイルのInputStream。
	 * @param filePath ファイルパス。
	 * @return Workbookオブジェクト（XSSFWorkbookまたはHSSFWorkbook）。
	 * @throws IOException ファイル読み込みエラー。
	 */
	private static Workbook createWorkbook(FileInputStream fis, String filePath) throws IOException {
		logger.debug("Creating workbook for file: {}", filePath);

		if (filePath.endsWith(".xlsx")) {
			logger.info("Detected XLSX file.");
			return new XSSFWorkbook(fis); // Excel 2007 以上
		} else if (filePath.endsWith(".xls")) {
			logger.info("Detected XLS file.");
			return new HSSFWorkbook(fis); // Excel 97-2003
		} else {
			logger.error("Unsupported file format: {}", filePath);
			throw new IllegalArgumentException("Unsupported file format: " + filePath);
		}
	}

	/**
	 * セルの値を取得します。
	 * 
	 * @param cell セルオブジェクト。
	 * @return セルの値（String、int、booleanなど）。
	 */
	private static Object getCellValue(Cell cell) {
		if (cell == null)
			return null;

		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue().trim();
		case NUMERIC:
			return (int) cell.getNumericCellValue();
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case FORMULA:
			return cell.getCellFormula();
		case BLANK:
		default:
			return null;
		}
	}

	/**
	 * シートが空かどうかをチェックします。
	 * 
	 * @param sheet チェックするシート。
	 * @return シートが空であればtrue、そうでなければfalse。
	 */
	private static boolean isSheetEmpty(Sheet sheet) {
		if (sheet == null) {
			return true;
		}

		for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			Row row = sheet.getRow(rowIndex);
			if (row != null && !isRowEmpty(row)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 行が空であるかどうかをチェックします。
	 * 
	 * @param row チェックする行。
	 * @return 行が空であればtrue、そうでなければfalse。
	 */
	private static boolean isRowEmpty(Row row) {
		for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
			Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
			if (cell.getCellType() != CellType.BLANK) {
				if (cell.getCellType() == CellType.STRING && !cell.getStringCellValue().trim().isEmpty()) {
					return false;
				}

				if (cell.getCellType() != CellType.STRING) {
					return false;
				}
			}
		}
		return true;
	}

	public static void writeExcel(String folderPath, List<EmployeeDAO> employees, ProgressCallback callback) {
		LocalDateTime localDateTime = LocalDateTime.now();
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
		String formattedDateTime = localDateTime.format(dateTimeFormatter);

		String fullPath = Paths.get(folderPath, "社員情報データ_" + formattedDateTime + ".xlsx").toString();
		File file = new File(fullPath);

		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("sheet1");
			createHeaderRow(sheet);
			int rowIndex = 1;
			if (employees != null && !employees.isEmpty()) {
				for (EmployeeDAO emp : employees) {
					Row row = sheet.createRow(rowIndex++);
					createRow(row, emp);
					if (callback != null) {
						callback.onProgress(rowIndex, employees.size());
					}
				}
			}else {
				if (callback != null) {
					callback.onProgress(1, 1);
				}
			}
			try (FileOutputStream fileOut = new FileOutputStream(file)) {
				workbook.write(fileOut);
				logger.info("Export Successful");
			}

		} catch (IOException e) {
			logger.error("Write Excel failed ", e);
		}
	}

	private static void createHeaderRow(Sheet sheet) {
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("社員番号");
		headerRow.createCell(1).setCellValue("氏名（フリガナ）");
		headerRow.createCell(2).setCellValue("氏名");
		headerRow.createCell(3).setCellValue("氏名（漢字）");
		headerRow.createCell(4).setCellValue("在籍区分");
		headerRow.createCell(5).setCellValue("部門コード");
		headerRow.createCell(6).setCellValue("性別");
		headerRow.createCell(7).setCellValue("血液型");
		headerRow.createCell(8).setCellValue("生年月日");
		headerRow.createCell(9).setCellValue("作成日");
		headerRow.createCell(10).setCellValue("更新日");

	}

	private static void createRow(Row row, EmployeeDAO emp) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		row.createCell(0).setCellValue(emp.getShainNo());
		row.createCell(1).setCellValue(emp.getShimeiKana());
		row.createCell(2).setCellValue(emp.getShimei());
		row.createCell(3).setCellValue(emp.getShimeiEiji());
		row.createCell(4).setCellValue(emp.getZaisekiKb());
		row.createCell(5).setCellValue(emp.getBumonCd());
		row.createCell(6).setCellValue(emp.getSeibetsu());
		row.createCell(7).setCellValue(emp.getKetsuekiGata());

		row.createCell(8)
				.setCellValue(emp.getBirthDate() != null ? emp.getBirthDate().format(dateTimeFormatter) : null);
		row.createCell(9).setCellValue(emp.getCreate() != null ? emp.getCreate().format(dateTimeFormatter) : null);
		row.createCell(10).setCellValue(emp.getUpdate() != null ? emp.getUpdate().format(dateTimeFormatter) : null);

	}
}
