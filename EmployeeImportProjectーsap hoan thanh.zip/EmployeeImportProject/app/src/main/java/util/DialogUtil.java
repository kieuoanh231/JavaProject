package util;

import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import javafx.stage.Window;

public class DialogUtil {

	/**
	 * 現在表示されているウィンドウを取得します。
	 * 
	 * @return (Stage) window 現在表示されているウィンドウのStageオブジェクト。
	 */
	private static Stage getCurrentStage() {
		Window window = javafx.stage.Window.getWindows().stream().filter(Window::isShowing).findFirst().orElse(null);
		return (Stage) window;
	}

	/**
	 * 情報メッセージを表示します。
	 * 
	 * @param message メッセージ内容。
	 * @param title ダイアログのタイトル。
	 */
	public static void showInfoMessage(String message, String title) {
		Stage currentStage = getCurrentStage();
		if (currentStage != null) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.initOwner(currentStage);
			alert.setTitle(title);
			alert.setHeaderText(null);
			alert.setContentText(message);

			alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
			alert.getDialogPane().setMaxHeight(Region.USE_PREF_SIZE);

			alert.getDialogPane().getStylesheets()
					.add(DialogUtil.class.getResource("/style/alert-style.css").toExternalForm());

			alert.showAndWait();
		}
	}

	/**
	 * エラーメッセージを表示します。
	 * 
	 * @param message メッセージ内容。
	 * @param title ダイアログのタイトル。
	 */
	public static void showErrorMessage(String message, String title) {
		Stage currentStage = getCurrentStage();
		if (currentStage != null) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.initOwner(currentStage);
			alert.setTitle(title);
			alert.setHeaderText(null);
			alert.setContentText(message);

			alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
			alert.getDialogPane().setMaxHeight(Region.USE_PREF_SIZE);

			alert.getDialogPane().getStylesheets()
					.add(DialogUtil.class.getResource("/style/alert-style.css").toExternalForm());

			alert.showAndWait();
		}
	}

	/**
	 * 確認ダイアログを表示します。
	 * 
	 * @param message メッセージ内容。
	 * @param title ダイアログのタイトル。
	 * @return 0（続行）または1（中止）。
	 */
	public static int showConfirmDialog(String message, String title) {
		Stage currentStage = getCurrentStage();
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.initOwner(currentStage);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);

		ButtonType buttonContinue = new ButtonType("続行", ButtonData.YES);
		ButtonType buttonCancel = new ButtonType("中止", ButtonData.NO);

		alert.getButtonTypes().setAll(buttonContinue, buttonCancel);

		alert.getDialogPane().getStylesheets()
				.add(DialogUtil.class.getResource("/style/alert-style.css").toExternalForm());

		alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
		alert.getDialogPane().setMaxHeight(Region.USE_PREF_SIZE);
		Optional<ButtonType> result = alert.showAndWait();
		if (result.isPresent()) {
			if (result.get() == buttonContinue) {
				return 0;
			}
		}

		return 1;
	}

}
