package util;

@FunctionalInterface
public interface ProgressCallback {
	void onProgress(int current, int total);
}
