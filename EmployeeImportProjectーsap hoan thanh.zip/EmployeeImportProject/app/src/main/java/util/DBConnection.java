package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DBConnection {
	private static final String url = "jdbc:postgresql://localhost:5432/employee_db";
	private static final String user = "postgres";
	private static final String password = "solekia";
	private static final Logger logger = LogManager.getLogger(DBConnection.class);

	/**
	 * データベースへの接続を取得します。 JDBCを使用してデータベースに接続し、接続オブジェクトを返します。
	 * 
	 * @return データベース接続のConnectionオブジェクト。接続に失敗した場合はnullを返します。
	 */
	public static Connection getConnection() {
		try {
			Connection conn = DriverManager.getConnection(url, user, password);
			logger.info("Database connection established successfully.");
			return conn;
		} catch (SQLException e) {
			logger.error("Failed to connect to the database. URL: {}, user: {}", url, user, e);
			return null;
		}
	}

}
