package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import repository.EmployeeDAO;
import repository.EmployeeRepository;

public class EmployeeViewModel {
	private static final Logger logger = LogManager.getLogger(EmployeeViewModel.class);

	private EmployeeDAO employeeDAO;
	private final EmployeeRepository employeeRepository;
	private int addCount = 0;
	private int updateCount = 0;

	public EmployeeViewModel() {
		this.employeeDAO = new EmployeeDAO();
		this.employeeRepository = new EmployeeRepository();
	}

	public void setEmployeeDAO(EmployeeDAO newEmployeeDAO) {
		this.employeeDAO.setShainNo(newEmployeeDAO.getShainNo());
		this.employeeDAO.setShimeiKana(newEmployeeDAO.getShimeiKana());
		this.employeeDAO.setShimei(newEmployeeDAO.getShimei());
		this.employeeDAO.setShimeiEiji(newEmployeeDAO.getShimeiEiji());
		this.employeeDAO.setZaisekiKb(newEmployeeDAO.getZaisekiKb());
		this.employeeDAO.setBumonCd(newEmployeeDAO.getBumonCd());
		this.employeeDAO.setSeibetsu(newEmployeeDAO.getSeibetsu());
		this.employeeDAO.setKetsuekiGata(newEmployeeDAO.getKetsuekiGata());
		this.employeeDAO.setBirthDate(newEmployeeDAO.getBirthDate());
		this.employeeDAO.setCreate(newEmployeeDAO.getCreate());
		this.employeeDAO.setUpdate(newEmployeeDAO.getUpdate());
	}

	public int getAddCount() {
		return this.addCount;
	}

	public int getUpdateCount() {
		return this.updateCount;
	}

	public IntegerProperty shainNoProperty() {
		return employeeDAO.shainNoProperty();
	}

	public StringProperty shimeiKanaProperty() {
		return employeeDAO.shimeiKanaProperty();
	}

	public StringProperty shimeiProperty() {
		return employeeDAO.shimeiProperty();
	}

	public StringProperty shimeiEijiProperty() {
		return employeeDAO.shimeiEijiProperty();
	}

	public StringProperty zaisekiKbProperty() {
		return employeeDAO.zaisekiKbProperty();
	}

	public StringProperty bumonCdProperty() {
		return employeeDAO.bumonCdProperty();
	}

	public StringProperty seibetsuProperty() {
		return employeeDAO.seibetsuProperty();
	}

	public StringProperty ketsuekiGataProperty() {
		return employeeDAO.ketsuekiGataProperty();
	}

	public ObjectProperty<LocalDate> birthDateProperty() {
		return employeeDAO.birthDateProperty();
	}

	/**
	 * 現在の社員データを取得します。
	 * 
	 * @return employeeDAO 現在の社員データ。
	 */
	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public List<EmployeeDAO> getEmployees() {
		List<EmployeeDAO> employees = new ArrayList<>();
		employees = employeeRepository.getAllEmployees();
		return employees;
	}

	/**
	 * データベースに複数の社員データを追加します。
	 * 
	 * @param excelList Excelから取得した社員データのリスト。
	 */
	public void addEmployees(List<EmployeeDAO> excelList) {
		employeeRepository.insertEmployeesBatch(excelList);
		addCount = excelList.size();
		logger.debug("Finished bulk add operation. Total added: {}", addCount);
	}

	/**
	 * Excelから取得した社員データとデータベースの社員データを比較し、 存在しない社員のみをデータベースに追加します。
	 * 
	 * @param excelList Excelから取得した社員データのリスト。
	 */
	public void compareAndAddEmployee(List<EmployeeDAO> excelList) {
		logger.info("Comparing Excel employees with DB and adding new ones...");
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();

		logger.debug("Retrieved {} employees from DB", dbList.size());
		Set<Integer> existingEmployeeIds = new HashSet<>();
		List<EmployeeDAO> addList = new ArrayList<>();

		for (EmployeeDAO employee : dbList) {
			existingEmployeeIds.add(employee.getShainNo());
		}
		logger.debug("Existing employee IDs in DB: {}", existingEmployeeIds);

		for (EmployeeDAO employee : excelList) {
			if (!existingEmployeeIds.contains(employee.getShainNo())) {
				logger.debug("New employee found in Excel, will be added: {}", employee.getShainNo());
				addList.add(employee);
			}
		}

		if (addList != null && !addList.isEmpty()) {
			logger.info("Adding {} new employees to DB...", addList.size());
			employeeRepository.insertEmployeesBatch(addList);
			addCount = addList.size();
			logger.info("Successfully added {} employees.", addCount);
		} else {
			logger.info("No new employees to add.");
		}

	}

	/**
	 * 社員データをデータベースで更新します。
	 */
	public void updateEmployee() {
		logger.info("Updating employee: {}", employeeDAO.getShainNo());
		employeeRepository.updateEmployee(employeeDAO);
	}

	/**
	 * Excelから取得した社員データを追加および更新します。 データベース内の社員データと照合し、存在する場合は更新し、存在しない場合は追加します。
	 * 
	 * @param excelList Excelから取得した社員データのリスト。
	 */
	public void addAndUpdateEmployee(List<EmployeeDAO> excelList) {
		logger.info("Starting to add/update employees from Excel...");
		List<EmployeeDAO> dbList = employeeRepository.getAllEmployees();

		logger.debug("Retrieved {} employees from DB for comparison", dbList.size());
		Set<Integer> existingEmployeeIds = new HashSet<>();
		List<EmployeeDAO> addList = new ArrayList<>();
		List<EmployeeDAO> updateList = new ArrayList<>();

		for (EmployeeDAO dbEmployee : dbList) {
			existingEmployeeIds.add(dbEmployee.getShainNo());
		}

		for (EmployeeDAO excelEmployee : excelList) {
			if (existingEmployeeIds.contains(excelEmployee.getShainNo())) {
				updateList.add(excelEmployee);
				logger.debug("Employee to update: {}", excelEmployee.getShainNo());
			} else {
				addList.add(excelEmployee);
				logger.debug("New employee to add: {}", excelEmployee.getShainNo());
			}
		}

		if (updateList != null && !updateList.isEmpty()) {
			logger.info("Updating {} employees...", updateList.size());
			employeeRepository.updateEmployeesBatch(updateList);
			updateCount = updateList.size();
			logger.info("Successfully updated {} employees.", updateCount);
		} else {
			logger.info("No employees to update.");
		}

		if (addList != null && !addList.isEmpty()) {
			logger.info("Adding {} new employees...", addList.size());
			employeeRepository.insertEmployeesBatch(addList);
			addCount = addList.size();
			logger.info("Successfully added {} employees.", addCount);
		} else {
			logger.info("No new employees to add.");
		}

	}

	/**
	 * 全ての社員データを削除します。
	 */
	public void deleteAllEmployees() {
		logger.info("Deleting all employees from database");
		employeeRepository.deleteAllEmployees();
	}

}
