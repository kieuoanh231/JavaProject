package controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import config.ConfigConstants;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import model.EmployeeViewModel;
import repository.EmployeeDAO;
import util.DialogUtil;
import util.ExcelUtil;

public class ExportController {
	private static final Logger logger = LogManager.getLogger(ExportController.class);

	@FXML
	private Accordion accordion1;

	@FXML
	private Accordion accordion2;

	@FXML
	private TitledPane titlePane1;

	@FXML
	private TitledPane titlePane2;

	@FXML
	private TextField txtPath;

	@FXML
	private ProgressBar progressBar;

	@FXML
	private Label loadingLabel;

	@FXML
	public void initialize() {
		accordion1.setExpandedPane(titlePane1);
		accordion2.setExpandedPane(titlePane2);
		logger.info("Initialization complete.");
		progressBar.setVisible(false);
		loadingLabel.setVisible(false);
	}

	@FXML
	public void handleFinishBtnAction() {
		logger.info("Exiting the application...");
		Platform.exit();
	}

	@FXML
	public void handleBrowseBtnAction() {
		DirectoryChooser diChooser = new DirectoryChooser();
		diChooser.setTitle("保存フォルダを選択してください");

		File selectedDirectory = diChooser.showDialog(null);
		if (selectedDirectory != null) {
			txtPath.setText(selectedDirectory.getAbsolutePath());
			logger.info("Folder selected: {}", selectedDirectory.getAbsolutePath());
		} else {
			logger.error("Selected folder is invalid.");
		}

	}

	@FXML
	private void handleExeButtonAction(ActionEvent event) {
		if (DialogUtil.showConfirmDialog(ConfigConstants.CONFIRM_EXECUTE, "確認") == 0) {
			String folderPath = txtPath.getText().trim();
			if (folderPath.isEmpty()) {
				logger.error(ConfigConstants.VALIDATE_FOLDERPATH_EMPTY);
				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_FOLDERPATH_EMPTY, ConfigConstants.MESSAGE);
				return;
			}

			Path path = Paths.get(folderPath);
			if (!Files.exists(path) || !Files.isDirectory(path)) {
				logger.error(ConfigConstants.VALIDATE_FOLDERPATH_EMPTY);
				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_FOLDERPATH_EMPTY, ConfigConstants.MESSAGE);
				return;
			}

			Task<Void> task = new Task<Void>() {
				AtomicBoolean userConfirmed = new AtomicBoolean(false);

				@Override
				protected Void call() throws Exception {
					updateProgress(0, 0);
					EmployeeViewModel eViewModel = new EmployeeViewModel();
					List<EmployeeDAO> employees = new ArrayList<>();
					employees = eViewModel.getEmployees();
					int total = employees.size();

					if (employees == null || employees.isEmpty()) {
						CountDownLatch latch = new CountDownLatch(1);
						Platform.runLater(() -> {
							int result = DialogUtil.showConfirmDialog("データがありません。Excelファイルの出力を続行しますか？", "確認");
							userConfirmed.set(result == 0);
							latch.countDown();
						});

						latch.await();
						if (!userConfirmed.get()) {
							return null;
						}
					}

					Platform.runLater(() -> {
						userConfirmed.set(true);
						progressBar.setVisible(true);
						loadingLabel.setVisible(true);
					});

					ExcelUtil.writeExcel(txtPath.getText(), employees, (current, max) -> {
						try {
							Thread.sleep(2);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						updateProgress(current, max);
					});

					updateProgress(total, total);
					return null;
				}

				@Override
				protected void succeeded() {
					super.succeeded();
					if (userConfirmed.get()) {
						progressBar.setVisible(false);
						loadingLabel.setVisible(false);
						DialogUtil.showInfoMessage("出力完了", ConfigConstants.MESSAGE);
					}
				}

				@Override
				protected void failed() {
					super.failed();
					progressBar.setVisible(false);
					loadingLabel.setVisible(false);
					DialogUtil.showErrorMessage("出力できません", ConfigConstants.MESSAGE);
				}
			};

			progressBar.progressProperty().bind(task.progressProperty());

			Thread thread = new Thread(task);
			thread.setDaemon(true);
			thread.start();
		}

	}

}
