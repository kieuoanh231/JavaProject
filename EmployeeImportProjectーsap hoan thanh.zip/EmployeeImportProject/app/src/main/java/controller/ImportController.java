package controller;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import config.ConfigConstants;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleGroup;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.EmployeeViewModel;
import repository.EmployeeDAO;
import util.DBConnection;
import util.DialogUtil;
import util.ExcelUtil;

public class ImportController {
	private static final Logger logger = LogManager.getLogger(ImportController.class);

	@FXML
	private RadioButton add_rBtn;

	@FXML
	private RadioButton add_update_rBtn;

	@FXML
	private RadioButton replace_rBtn;

	@FXML
	private TextField txtPath;

	@FXML
	private Accordion accordion1;

	@FXML
	private Accordion accordion2;

	@FXML
	private TitledPane titlePane1;

	@FXML
	private TitledPane titlePane2;

	private ToggleGroup toggleGroup;

	/**
	 * 初期化メソッド。
	 */
	@FXML
	public void initialize() {
		toggleGroup = new ToggleGroup();
		add_rBtn.setToggleGroup(toggleGroup);
		add_update_rBtn.setToggleGroup(toggleGroup);
		replace_rBtn.setToggleGroup(toggleGroup);

		accordion1.setExpandedPane(titlePane1);
		accordion2.setExpandedPane(titlePane2);
		logger.info("Initialization complete.");
	}

	/**
	 * アプリケーションを終了します。
	 */
	@FXML
	public void handleFinishBtnAction() {
		logger.info("Exiting the application...");
		Platform.exit();
	}

	/**
	 * Excelファイルを選択し、そのパスをテキストフィールドに表示します。
	 */
	@FXML
	public void handleBrowseBtnAction(ActionEvent event) {
		logger.info("Browsing for an Excel file...");
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Excelファイルを選択してください");

		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel files", "*.xlsx", "*.xls"));

		File selectedFile = fileChooser.showOpenDialog(null);
		if (selectedFile != null && selectedFile.exists() && selectedFile.isFile()) {
			txtPath.setText(selectedFile.getAbsolutePath());
			logger.info("File selected: {}", selectedFile.getAbsolutePath());
		} else {
			logger.error("Selected file is invalid.");
		}
	}

	/**
	 * Excelファイルを読み込み、データベースに追加・更新・置き換え処理を実行します。
	 */
	@FXML
	public void handleExeButtonAction() {
		logger.info("Execution button clicked.");
		if (DialogUtil.showConfirmDialog(ConfigConstants.CONFIRM_EXECUTE, "確認") == 0) {
			String filePath = txtPath.getText().trim();
			if (filePath.isEmpty()) {
				logger.error(ConfigConstants.VALIDATE_PATH_EMPTY);
				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_PATH_EMPTY, ConfigConstants.MESSAGE);
				return;
			}

			File file = new File(filePath);
			if (!file.exists() || !file.isFile()) {
				logger.error("File does not exist or is not a valid file: {}", filePath);
				DialogUtil.showErrorMessage(ConfigConstants.VALIDATE_PATH_EMPTY, ConfigConstants.MESSAGE);
				return;
			}

			try {
				List<EmployeeDAO> excelList = ExcelUtil.readExcel(filePath);

				if (excelList != null && !excelList.isEmpty() && !ExcelUtil.hasError) {
					logger.info("Excel file read successfully. Processing data...");
					Connection connection = DBConnection.getConnection();
					if (connection != null) {
						EmployeeViewModel employeeViewModel = new EmployeeViewModel();
						RadioButton selectedRadio = (RadioButton) toggleGroup.getSelectedToggle();

						switch (selectedRadio.getId()) {
						case "add_rBtn":
							logger.info("Adding new employees...");
							employeeViewModel.compareAndAddEmployee(excelList);
							DialogUtil.showInfoMessage("追加の件数： " + employeeViewModel.getAddCount(),
									ConfigConstants.MESSAGE);
							break;
						case "add_update_rBtn":
							logger.info("Adding and updating employees...");
							employeeViewModel.addAndUpdateEmployee(excelList);
							DialogUtil.showInfoMessage("追加の件数： " + employeeViewModel.getAddCount() + "\n更新の件数： "
									+ employeeViewModel.getUpdateCount(), ConfigConstants.MESSAGE);
							break;
						case "replace_rBtn":
							logger.info("Replacing all employees...");
							employeeViewModel.deleteAllEmployees();
							employeeViewModel.addEmployees(excelList);
							DialogUtil.showInfoMessage("全件消除後の追加の件数： " + employeeViewModel.getAddCount(),
									ConfigConstants.MESSAGE);
							break;
						default:
							logger.error("Unexpected radio button selection: {}", selectedRadio.getId());
							throw new IllegalArgumentException("Unexpected value: " + selectedRadio.getId());
						}
					}
				} else {
					logger.error("No valid data found in Excel file.");
				}

			} catch (Exception e) {
				logger.error("Error occurred while processing the Excel file: ", e);
				DialogUtil.showErrorMessage("エラーが発生しました。", ConfigConstants.MESSAGE);
			}

		}
	}

	@FXML
	public void handleSwitchScreenBtnAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/export_layout.fxml"));
			Parent root = loader.load();

			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root, 1024, 700);
			stage.setScene(scene);
			stage.show();

		} catch (IOException e) {
			logger.info("Switch Screen Failed ", e);
		}

	}
}
