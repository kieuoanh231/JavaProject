package model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import repository.EmployeeDAO;

public class EmployeeViewModel {
	private final EmployeeDAO employeeDAO;

	public EmployeeViewModel(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public IntegerProperty shainNoProperty() {
		return employeeDAO.shainNoProperty();
	}

	public StringProperty shimeiKanaProperty() {
		return employeeDAO.shimeiKanaProperty();
	}

	public StringProperty shimeiProperty() {
		return employeeDAO.shimeiProperty();
	}

	public StringProperty shimeiEijiProperty() {
		return employeeDAO.shimeiEijiProperty();
	}

	public StringProperty zaisekiKbProperty() {
		return employeeDAO.zaisekiKbProperty();
	}

	public StringProperty bumonCdProperty() {
		return employeeDAO.bumonCdProperty();
	}

	public StringProperty seibetsuProperty() {
		return employeeDAO.seibetsuProperty();
	}

	public StringProperty ketsuekiGataProperty() {
		return employeeDAO.ketsuekiGataProperty();
	}

	public void addEmployee() {
		// Logic save data to database
		System.err.println(shainNoProperty().get());
	}

	public void updateEmployee() {
		// Logic update data in database
	}

	public void deleteEmployee() {
		// Logic delete data from database
	}
}
