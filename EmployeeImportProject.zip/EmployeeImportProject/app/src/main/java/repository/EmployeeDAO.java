package repository;

import java.time.LocalDate;
import java.util.Date;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class EmployeeDAO {

	private final IntegerProperty shainNo = new SimpleIntegerProperty();
	private final StringProperty shimeiKana = new SimpleStringProperty();
	private final StringProperty shimei = new SimpleStringProperty();
	private final StringProperty shimeiEiji = new SimpleStringProperty();
	private final StringProperty zaisekiKb = new SimpleStringProperty();
	private final StringProperty bumonCd = new SimpleStringProperty();
	private final StringProperty seibetsu = new SimpleStringProperty();
	private final StringProperty ketsuekiGata = new SimpleStringProperty();
	private final ObjectProperty<LocalDate> birthDate = new SimpleObjectProperty<LocalDate>();
	private final ObjectProperty<Date> create = new SimpleObjectProperty<Date>();
	private final ObjectProperty<Date> update = new SimpleObjectProperty<Date>();

	public EmployeeDAO() {
		super();
	}

	public final IntegerProperty shainNoProperty() {
		return this.shainNo;
	}

	public final int getShainNo() {
		return this.shainNoProperty().get();
	}

	public final void setShainNo(final int shainNo) {
		this.shainNoProperty().set(shainNo);
	}

	public final StringProperty shimeiKanaProperty() {
		return this.shimeiKana;
	}

	public final String getShimeiKana() {
		return this.shimeiKanaProperty().get();
	}

	public final void setShimeiKana(final String shimeiKana) {
		this.shimeiKanaProperty().set(shimeiKana);
	}

	public final StringProperty shimeiProperty() {
		return this.shimei;
	}

	public final String getShimei() {
		return this.shimeiProperty().get();
	}

	public final void setShimei(final String shimei) {
		this.shimeiProperty().set(shimei);
	}

	public final StringProperty shimeiEijiProperty() {
		return this.shimeiEiji;
	}

	public final String getShimeiEiji() {
		return this.shimeiEijiProperty().get();
	}

	public final void setShimeiEiji(final String shimeiEiji) {
		this.shimeiEijiProperty().set(shimeiEiji);
	}

	public final StringProperty zaisekiKbProperty() {
		return this.zaisekiKb;
	}

	public final String getZaisekiKb() {
		return this.zaisekiKbProperty().get();
	}

	public final void setZaisekiKb(final String zaisekiKb) {
		this.zaisekiKbProperty().set(zaisekiKb);
	}

	public final StringProperty bumonCdProperty() {
		return this.bumonCd;
	}

	public final String getBumonCd() {
		return this.bumonCdProperty().get();
	}

	public final void setBumonCd(final String bumonCd) {
		this.bumonCdProperty().set(bumonCd);
	}

	public final StringProperty seibetsuProperty() {
		return this.seibetsu;
	}

	public final String getSeibetsu() {
		return this.seibetsuProperty().get();
	}

	public final void setSeibetsu(final String seibetsu) {
		this.seibetsuProperty().set(seibetsu);
	}

	public final StringProperty ketsuekiGataProperty() {
		return this.ketsuekiGata;
	}

	public final String getKetsuekiGata() {
		return this.ketsuekiGataProperty().get();
	}

	public final void setKetsuekiGata(final String ketsuekiGata) {
		this.ketsuekiGataProperty().set(ketsuekiGata);
	}

	public final ObjectProperty<LocalDate> birthDateProperty() {
		return this.birthDate;
	}

	public final LocalDate getBirthDate() {
		return this.birthDateProperty().get();
	}

	public final void setBirthDate(final LocalDate birthDate) {
		this.birthDateProperty().set(birthDate);
	}

	public final ObjectProperty<Date> createProperty() {
		return this.create;
	}

	public final Date getCreate() {
		return this.createProperty().get();
	}

	public final void setCreate(final Date create) {
		this.createProperty().set(new Date());
	}

	public final ObjectProperty<Date> updateProperty() {
		return this.update;
	}

	public final Date getUpdate() {
		return this.updateProperty().get();
	}

	public final void setUpdate(final Date update) {
		this.updateProperty().set(new Date());
	}

	@Override
	public String toString() {
		return "EmployeeDAO [shainNo=" + shainNo + ", shimeiKana=" + shimeiKana + ", shimei=" + shimei + ", shimeiEiji="
				+ shimeiEiji + ", zaisekiKb=" + zaisekiKb + ", bumonCd=" + bumonCd + ", seibetsu=" + seibetsu
				+ ", ketsuekiGata=" + ketsuekiGata + ", birthDate=" + birthDate + ", create=" + create + ", update="
				+ update + "]";
	}
}
