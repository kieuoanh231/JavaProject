package repository;

public class EmployeeRepository {

}
