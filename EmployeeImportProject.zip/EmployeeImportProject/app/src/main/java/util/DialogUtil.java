package util;

import javax.swing.JOptionPane;

public class DialogUtil {
	public static void showMessage(String message, String title) {
		JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
	}
}
