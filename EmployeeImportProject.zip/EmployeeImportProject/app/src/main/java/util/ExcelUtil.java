package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.ConfigConstants;
import repository.EmployeeDAO;

public class ExcelUtil {
	private static boolean hasError = false;

	public static List<EmployeeDAO> readExcel(String filePath) throws IOException {
		hasError = false;
		List<EmployeeDAO> listExcel = new ArrayList<>();

		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = createWorkbook(fis, filePath);
		Sheet sh = wb.getSheetAt(0);

		if (isSheetEmpty(sh) && isFirstRowEmpty(sh)) {
			System.out.println("sheet rong, khong co du lieu nao");
			return listExcel;
		}

		for (int rowIndex = 1; rowIndex < sh.getLastRowNum(); rowIndex++) {
			Row row = sh.getRow(rowIndex);
			Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = getColumnMapping(row.getRowNum() + 1);

			EmployeeDAO employeeDAO = new EmployeeDAO();

			for (int columnIndex = 0; columnIndex < columnMapping.size(); columnIndex++) {
				if (hasError) {
					return listExcel;
				}
				Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
				columnMapping.getOrDefault(columnIndex, (emp, c) -> {
				}).accept(employeeDAO, cell);
			}
			listExcel.add(employeeDAO);
		}

		return listExcel;
	}

	private static Map<Integer, BiConsumer<EmployeeDAO, Cell>> getColumnMapping(int rowNum) {
		Map<Integer, BiConsumer<EmployeeDAO, Cell>> columnMapping = new HashMap<>();
		List<String> kubunListTemp = Arrays.asList("A", "B", "C");
		List<String> bumonListTemp = Arrays.asList("A", "B", "C");
		List<String> seibetsuListTemp = Arrays.asList("女性", "男性", "その他");
		List<String> bloodListTemp = Arrays.asList("A", "B", "O");

		columnMapping.put(0, (emp, cell) -> {
			if (!ValidatorUtil.isNumeric(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NOT_NUMBER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.hasMoreThanFourDigits((int) cell.getNumericCellValue())) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NO_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShainNo((int) cell.getNumericCellValue());
		});

		columnMapping.put(1, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_FURIGANA_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimeiKana(cell.getStringCellValue());
		});

		columnMapping.put(2, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver30Characters(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_NAME_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimei(cell.getStringCellValue());
		});

		columnMapping.put(3, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_EMPTY,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			if (ValidatorUtil.isOver40Characters(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_EIJI_OVER,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setShimeiEiji(cell.getStringCellValue());
		});

		columnMapping.put(4, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, kubunListTemp)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_ZAISEKIKUBUN_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setZaisekiKb(cell.getStringCellValue());
		});

		columnMapping.put(5, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bumonListTemp)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BUMON_CODE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setBumonCd(cell.getStringCellValue());
		});

		columnMapping.put(6, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, seibetsuListTemp)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_GENDER_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setSeibetsu(cell.getStringCellValue());
		});

		columnMapping.put(7, (emp, cell) -> {
			if (!ValidatorUtil.isCellNotEmpty(cell) || ValidatorUtil.isNotInList(cell, bloodListTemp)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BLOOD_TYPE_NOT_EXIST,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setKetsuekiGata(cell.getStringCellValue());
		});

		columnMapping.put(8, (emp, cell) -> {
			System.err.println(ValidatorUtil.isValidDate(cell));
			if (!ValidatorUtil.isValidDate(cell)) {
				DialogUtil.showMessage("行番号：" + rowNum + "、 " + ConfigConstants.VALIDATE_BIRTHDATE,
						ConfigConstants.MESSAGE);
				hasError = true;
				return;
			}

			emp.setBirthDate(cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		});

		return columnMapping;
	}

	private static Workbook createWorkbook(FileInputStream fis, String filePath) throws IOException {
		if (filePath.endsWith(".xlsx")) {
			return new XSSFWorkbook(fis); // Excel 2007 以上
		} else if (filePath.endsWith(".xls")) {
			return new HSSFWorkbook(fis); // Excel 97-2003
		} else {
			throw new IllegalArgumentException("Định dạng file không hợp lệ: " + filePath);
		}
	}

	private static boolean isSheetEmpty(Sheet sheet) {
		return sheet == null || sheet.getPhysicalNumberOfRows() == 0;
	}

	private static boolean isRowEmpty(Row row) {
		if (row == null)
			return true;
		for (Cell cell : row) {
			if (cell.getCellType() != CellType.BLANK) {
				return false;
			}
		}
		return true;
	}

	private static boolean isFirstRowEmpty(Sheet sheet) {
		Row firstRow = sheet.getRow(0);
		if (firstRow == null) {
			return true;
		}

		for (Cell cell : firstRow) {
			if (cell != null && !cell.toString().trim().isEmpty()) {
				return false;
			}
		}
		return true;
	}
}
